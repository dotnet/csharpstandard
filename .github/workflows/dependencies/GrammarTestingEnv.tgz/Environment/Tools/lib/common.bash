# Library of common bash functions

# There is no concept of function return value in bash so to return a value
# many of this library functions take a variable name and set this variable
# indirectly using an eval – we’ll call this pass-by-name (it isn’t really).
# This means the functions cannot internally use the same name for a variable,
# even “local” ones, as the passed in pass-by-name variable, which as the
# latter is unknown is impossible...
#
# To deal with this in this library all internal names begin with an underscore
# and pass-by-name arguments cannot start with an underscore, __checkPassByName()
# enforces this.

__checkPassByName () # destVarName
{
   if [[ "$1" == "" ]]; then
      echo "SCRIPT ERROR: Empty string used for pass-by-name variable name" 1>&2
      echo "At: " ${FUNCNAME[*]} 1>&2
      exit -1   
   elif [[ ("$1" == _*) && ("$1" != __*) ]]; then
      echo "SCRIPT ERROR: $1 – pass-by-name variable names cannot start with underscore" 1>&2
      echo "At: " ${FUNCNAME[*]} 1>&2
      exit -1
   fi
}

# Display usage message, the per script text must be sent to stdout by _usageDescription
# With optional error message and exit code the output will be redirected to stderr

usage() # [optErrorMsg [optExitCode]]
{
   # name the parameters
   local _optErrorMsg="$1"
   local _optExitCode="${2:--1}" # default to -1
   
   # if optErrorMsg exists send all output to stderr
   if [ "$_optErrorMsg" != "" ]; then
      echo "Error: $_optErrorMsg" 1>&2
      echo 1>&2
      _usageDescription 1>&2
      echo 1>&2
      exit $_optExitCode
   else
      echo
      _usageDescription
      echo
   fi
}

# Send errorMsg to stderr

errorEcho() # any number of args
{
   echo "$@" 1>&2
}

# Send errorMsg to stderr and exit with provided exit code or -1

errorExit() # errorMsg [optExitCode]
{
   # name the parameters
   local _errorMsg="$1"
   local _exitCode="${2:--1}" # default to -1
   
   echo "ERROR: $_errorMsg" 1>&2
   exit $_exitCode
}

# Verbosity options, both unset by default
# only exported after being set within a command,
# so the settings flow down to called commands.
# They are not set as part of environment setup
# as if that is source'ed at command level the
# settings would carry over between commands.

setVerbose()
{
   export BG_VERBOSE=true
   export BG_QUIET=false
}

setQuiet()
{
   export BG_VERBOSE=false
   export BG_QUIET=true
}

setDebug()
{
   export BG_DEBUG=true
}

# predicate checks. check return status

isVerbose()
{
   if [[ "$BG_VERBOSE" = true ]]; then
      return 0
   else
      return 1
   fi
}

isQuiet()
{
   if [[ "$BG_QUIET" = true ]]; then
      return 0
   else
      return 1
   fi
}

# if $BG_VERBOSE send all args to stdout

verboseEcho() # any number of args
{
   if [[ "$BG_VERBOSE" = true ]]; then
      echo "$@"
   fi
}

# if !$BG_QUIET send all args to stdout

infoEcho() # any number of args
{
   if [[ "$BG_QUIET" != true ]]; then
      echo "$@"
   fi
}

# if $BG_QUIET send all args to stdout

quietEcho() # any number of args
{
   if [[ "$BG_QUIET" == true ]]; then
      echo "$@"
   fi
}

# send message to stdout, selecting based on quiet if two args

infoOrQuietMessage() # msg [quietMsg]
{
   if [[ $# == 1 ]]; then
      echo "$1"
   elif isQuiet; then
      echo "$2"
   else
      echo "$1"
   fi     
}

# if $BG_DEBUG send all args to stdout

debugEcho() # any number of args
{
   if [[ "$BG_DEBUG" = true ]]; then
      echo "$@"
   fi
}

# mkdir without error messages

quietMkdir() # directory path
{
   # OK if already exists
   if [[ -d "$1" ]]; then return 0; fi
   # silence error messages while retaining status return   
   mkdir "$1" 2>/dev/null
}

# mkdir with exit on error

mkdirOrExit() # directory [errorMsg]
{
   if quietMkdir "$1" ; then
      return
   fi
   
   if [[ "$2" != "" ]]; then
      errorExit "$2" $?
   else
      errorExit "Internal error, failed to mkdir \"$2\"" $?
   fi
}

# Validate a file path and set destVarName to its absolute path
# On failure send errorMsg to stderr, and if there is an optional exitCode exit

validateFilePath() # destVarName filePath [optExitCode]
{
   # check destVarName is OK
   __checkPassByName "$1"

   # name the parameters
   local _destVarName="$1"
   local _filePath="$2"
   local _optExitCode="$3"
   
   if [[ ! ( -f "$_filePath" ) ]]; then
      echo "\"$_filePath\" does not exist" 1>&2
      if [ "$_optExitCode" != "" ]; then
         exit $_optExitCode
      fi
   fi

   local _dirPath=`cd "$(dirname "$_filePath")" && realpath .`
   local _fileName=$(basename "$_filePath") 
   eval $_destVarName="\"$_dirPath/$_fileName\""
}

# Validate a directory path and set destVarName to its absolute path
# On failure send errorMsg to stderr, and if there is an optional exitCode exit

validateDirectoryPath() # destVarName dirPath errorMsg [optExitCode]
{
   # check destVarName is OK
   __checkPassByName "$1"

   # name the parameters
   local _destVarName="$1"
   local _dirPath="$2"
   local _errorMsg="$3"
   local _optExitCode="$4"

   local _fullPath=`test -d "$_dirPath" && cd "$_dirPath" && realpath .`
   if [ "$_fullPath" = "" ]; then
      echo "$_errorMsg" 1>&2
      if [ "$_optExitCode" != "" ]; then
         exit $_optExitCode
      fi
   else
      eval $_destVarName="\"$_fullPath\""
   fi
}

# Similar to validateDirectoryPath except if the directory does not exist
# but its parent does then the directory is created

validateOrCreateDirectoryPath() # destVarName dirPath errorMsg [optExitCode]
{
   # check destVarName is OK
   __checkPassByName "$1"

   # name the parameters
   local _destVarName="$1"
   local _dirPath="$2"
   local _errorMsg="$3"
   local _optExitCode="$4"
   
   local _fullPath=`test -d "$_dirPath" && cd "$_dirPath" && realpath .`
   if [ "$_fullPath" != "" ]; then
      # dirPath exists, return its full path
      eval $_destVarName="\"$_fullPath\""
   else
      # dirPath does not exist, check it's parent
      local _parentPath=$(dirname "$_dirPath")
      if [[ -d "$_parentPath" ]]; then
         # parent exists, create child
         if quietMkdir "$_dirPath" ; then
            eval $1="\"$(cd "$_dirPath" && realpath .)\""
         else
            errorExit "$_errorMsg" $?
         fi         
      else
         errorEcho "$_errorMsg"
         if [ "$_optExitCode" != "" ]; then
            exit $_optExitCode
         fi
      fi      
   fi
}

# Validate jarPath.
# Directory part of the path is handled by validateOrCreateDirectoryPath()
# If file part is missing uses defaultName.jar
# errorMsg & optExist code handled as above

validateJarPath() # destVarName jarPath defaultName errorMsg [optExitCode]
{
   # check destVarName is OK
   __checkPassByName "$1"

   # name the parameters
   local _destVarName="$1"
   local _jarPath="$2"
   local _defaultName="$3"
   local _errorMsg="$4"
   local _optExitCode="$5"

   local _jarFile
   local _jarDir
   
   # split jarPath into file & dir parts, constructing file if not included
   if [[ "$_jarPath" = *.jar ]]; then
      _jarFile=$(basename "$_jarPath")
      _jarDir=$(dirname "$_jarPath")
   else
      _jarFile="${_defaultName}.jar"
      _jarDir="$_jarPath"
   fi
   
   # now check jarDir
   # note: to avoid risk of name clashes use a return variable starting with double underscores
   local __jarDir
   validateOrCreateDirectoryPath __jarDir "$_jarDir" "$_errorMsg" "$_optExitCode"
   
   eval $_destVarName="\"${__jarDir}/${_jarFile}\""
}

# Validate or create working directory

validateOrCreateWorkingDirectory() # suggestedPath namePrefix refWorkingDirectory refDoCleanup
{
# handle $optWorkingDirectory, if present validate and set $workingDirectory to path
# and set $doCleanup to false. Otherwise create a temporary directory, set $workingDirectory
# to its path and set $doCleanup to true to indicate it should be removed on completion

   # check output vars are OK
   __checkPassByName "$3"
   __checkPassByName "$4"

   # name parameters 
   local _suggestedPath="$1"        # if not empty validate/create, if empty create a temporary directory
   local _namePrefix="$2"           # prefix for temporary directory name
   local _refWorkingDirectory="$3"  # name of variable to receive full path of working directory
   local _refDoCleanup="$4"         # name of variable to receive cleanup flag: true -> remove temporary working directory
   

   if [[ "$_suggestedPath" != "" ]]; then
      validateOrCreateDirectoryPath $_refWorkingDirectory "$_suggestedPath" "Working directory \"$optWorkingDirectory\" invalid" -1
      eval "$_refDoCleanup=false"
   else
      # TMPDIR is supposed to be defined on macOS & Linux, but guess what its missing on Ubuntu
      if [[ ! -d "$TMPDIR" ]]; then
         if [[ -d "$TMP" ]]; then
            TMPDIR=$TMP
         elif [[ -d /var/tmp ]]; then
            TMPDIR=/var/tmp
         else
            TMPDIR=/tmp
         fi
      fi
      # now TMPDIR *is* defined
      
      local _tempWorkingDirectory="$(echo ${TMPDIR}/${_namePrefix}_$$_${RANDOM})"
      if [[ -d "$_tempWorkingDirectory" ]]; then
         errorExit "Private working directory \"$(realpath $_tempWorkingDirectory)\" already exists, contact developer"
      elif quietMkdir "$_tempWorkingDirectory" ; then
         local _realWorkingDirectory=$(realpath "$_tempWorkingDirectory")
         eval "$_refWorkingDirectory=\"$_realWorkingDirectory\""
         eval "$_refDoCleanup=true"
      else
         errorExit "Private working directory \"$_tempWorkingDirectory\" could not be created" $?
      fi
   fi
}

####################################################################################################################################

# Function to search for a particular named directory
# used by the testing framework collection of scripts
#
# All args may be passed as empty strings, passing
# an empty string for returnVar or failing to locate
# the directory will result in a fatal error message
#
# First arg, returnVar, must be the name of a variable
# following the call-by-name convention.
#
# Last arg, argKind, should contain a word describing
# the kind of directory searched for. It is used in
# the error message (“...argName argKind directory...”)
# if the function aborts.
#
# Search order:
# - argDirectPath: a possible direct path
# - Search for argName, a simple name:
#   - in argContainerPath: a path
#   - in CWD
#   - in argLibContainerPath
#   - in argScriptDir: directory of calling script

searchForDirectory() # returnVar argDirectPath argName argContainerPath argLibContainerPath argScriptDir argKind
{
   __checkPassByName "$1"

   local _returnVar="$1"
   local _argDirectPath="$2"
   local _argName="$3"
   local _argContainerPath="$4"
   local _argLibContainerPath="$5"
   local _argScriptDir="$6"
   local _argKind="$7"
   
   local _foundPath
   local _foundSrc
   local _notFound=false
   
   if [[ ("$_argDirectPath" != "") && (-d "$_argDirectPath") ]]; then
      _foundPath="$_argDirectPath"
      _foundSrc=ADP
   elif [[ "$_argName" != "" ]]; then
      if [[ ("$_argContainerPath" != "") && (-d "${_argContainerPath}/${_argName}") ]]; then
         _foundPath="${_argContainerPath}/${_argName}"
         _foundSrc=ACP
      elif [[ -d "./${_argName}" ]]; then
         _foundPath="./${_argName}"
         _foundSrc=CWD
      elif [[ ("$_argLibContainerPath" != "") && (-d "${_argLibContainerPath}/${_argName}") ]]; then
         _foundPath="${_argLibContainerPath}/${_argName}"
         _foundSrc=LIB
      elif [[ ("$_argScriptDir" != "") && (-d "${_argScriptDir}/${_argName}") ]]; then
         _foundPath="${_argScriptDir}/${_argName}"
         _foundSrc=ADJ
      else
         _notFound=true
      fi
   else
      _notFound=true
   fi
   
   if [[ $_notFound == true ]]; then
      # avoid double space if no argKind
      if [[ "$_argKind" == "" ]]; then
         errorEcho "Could not locate the ${_argName} directory"
      else
         errorEcho "Could not locate the ${_argName} ${_argKind} directory"
      fi
      errorExit "Consult the documentation"
   fi
   
   _foundPath="$(realpath "$_foundPath")"

   debugEcho "${_argName} = [$_foundSrc] ${_foundPath}"
  
   eval ${_returnVar}="\"$_foundPath"\"
}

####################################################################################################################################

# Functions for testing standard samples

# A standard sample has:
#  • A sole <name>.cs file
#  • A folder Reference
#  • A file Reference/<name>.tree.txt
#  • A file _Sample_Options.txt

# isStandardSample
#    refRootName – name of variable to return root name in
#    dirName     – path of the folder to test, may be relative to CWD
#  
# On success returns the root name via refRootName
  
isStandardSample() # refRootName dirName dirPath
{
   # check refRootName is OK
   __checkPassByName "$1"

   local _refRootName="$1"
   local _dirName="$2"
   
   local _restoreNullGlob=$(shopt -p nullglob)  # save the current nullglob setting
   shopt -s nullglob                            # set nullglob
   pushd "$_dirName" 1>/dev/null                # push silently
   {
      local _csfiles=( *.cs )
      
      debugEcho "_csfiles = |${_csfiles[@]}|"
      
      local _returnStatus=-1                    # default to fail
      
      # only one .cs?
      if [[ ${#_csfiles[@]} == 1 ]]; then
      
         # extract rootName
         local _targetFile=${_csfiles[0]}
         local _rootName=${_targetFile:0:${#_targetFile}-3} # drop trailing .cs   
         
         debugEcho "_targetFile = $_targetFile"
         debugEcho "_rootName = $_rootName"
         
         # check other conditions
         if [[ (-f "$_targetFile")                           # check the .cs is a file
            && (  (-f "Reference/${_rootName}.tree.txt")     # check the reference tree exists
               || (-f "Reference/${_rootName}.tree.red.txt")
               )
            && (-f "_Sample_Options.txt")                  # check the options file exists      
            ]] ;
         then
            _returnStatus=0 # success
         fi
      fi
   }
   popd 1>/dev/null                             # popd silently
   eval "$_restoreNullGlob"                     # restore nullglob setting
   
   if [[ $_returnStatus == 0 ]]; then
      eval "$_refRootName=\"$_rootName\""
   fi
   
   return $_returnStatus
}

# testStandardSample
#    dirName          – path of sample directory
#    rootName         – root name of sample files (dirName/rootname.cs & dirName/Reference/rootname.tree.text)
#    parserDirectory  – the parser library
#    workingDirectory – where to create working files
#    sampleName       - optional name for sample, if omitted derived from dirName
#    useReduceTree    - optional bool, if omitted default to false
#
# Only called if isStandardSample() so no need to check all relevant files exist
# Does need to check if the correct parser is available

testStandardSample() # dirName rootName parserDirectory workingDirectory [sampleName]
{
   local dirName="$1"
   local rootName="$2"
   local parserDirectory="$3"
   local workingDirectory="$4"
   local sampleName=${5:-$(basename "$(realpath "$dirName")")}
   
   debugEcho "dirName = $dirName"
   debugEcho "rootName = $rootName"
   debugEcho "parserDirectory = $parserDirectory"
   debugEcho "workingDirectory = $workingDirectory"
   debugEcho "sampleName = $sampleName"

   # This group will abort on error rather than return failure
   {
      # get the GrunTreeParser
      local grunTreePath="${parserDirectory}/GrunTreeParser.jar"
      if [[ ! -f "$grunTreePath" ]]; then
         errorExit "GrunTreeParser not found, contact developer"
      fi
   }
   
   # read in the options
   
   local setName=
   local useReduceTree=false
   
   local requireArgument=
   
   for i in $(< "${dirName}/_Sample_Options.txt"); do
      if [[ "$requireArgument" == "" ]]; then
         case "$i" in
            -rt|--reduce-tree)
               useReduceTree=true
               ;;
            -ms=*|--modification-set=*)
               if [[ "$setName" == "" ]]; then
                  setName="${i#*=}"
               else
                  infoEcho "Unexpected sample option $i, ignoring"
               fi
               ;;
            -ms|--modification-set)
               if [[ "$setName" == "" ]]; then
                  requireArgument=$i
               else
                  infoEcho "Unexpected sample option $i, ignoring"
               fi
               ;;
            *)
               infoEcho "Unrecognised sample option $i, ignoring"
               ;;
         esac
      else # looking for argument after option
         if [[ "$i" == -* ]]; then
            infoEcho "Sample option $requireArgument missing argument, ignoring"
            requireArgument=
         else
            case $requireArgument in
               -ms|--modification-set)
                  setName="$i"
                  requireArgument=
                  ;;
            esac
            if [[ "$requireArgument" != "" ]]; then
               errorExit "Internal error, argument expected on none argument option, contact developer"
            fi
         fi      
      fi
   done
   
   debugEcho "setName = $setName"
   debugEcho "useReduceTree = $useReduceTree"
   
   if [[ "$setName" == "" ]]; then
      errorEcho "No modification set specified in the `_Sample_Options.txt` file"
      return -1
   fi

   # get the C# parser
   local parserPath="${parserDirectory}/${setName}Parser.jar"
   if [[ ! -f "$parserPath" ]]; then
      errorEcho "Sample ${sampleName}’s _Sample_Options.txt contains unknown set name “${setName}”"
      return -1
   fi
   
   infoEcho "*** Using: $setName"
   
   # argument variables
   local reduceTreeArg=
   local sampleSource="${dirName}/${rootName}.cs"
   local referenceStdErrFile="${dirName}/Reference/${rootName}.stderr.txt"
   local referenceTreeFile="${dirName}/Reference/${rootName}.tree.txt"
   local tempStdErrFile="${sampleWorkingDirectory}/${rootName}.stderr.txt"
   local tempSampleTreeFile="${sampleWorkingDirectory}/${rootName}.tree.txt"
   local tempSampleGrunTreeFile="${sampleWorkingDirectory}/${rootName}.gruntree.txt"
   local tempReferenceGrunTreeFile="${sampleWorkingDirectory}/Reference_$$.gruntree.txt"
   

   # to reduce or not to reduce...
   if [[ "$useReduceTree" == true ]]; then
      reduceTreeArg="-rt"
      referenceTreeFile=${referenceTreeFile/%.txt/.red.txt}
      tempSampleTreeFile=${tempSampleTreeFile/%.txt/.red.txt}
      tempSampleGrunTreeFile=${tempSampleGrunTreeFile/%.txt/.red.txt}
      tempReferenceGrunTreeFile=${tempReferenceGrunTreeFile/%.txt/.red.txt}
   fi
   
   debugEcho "reduceTreeArg = $reduceTreeArg"
   debugEcho "sampleSource = $sampleSource"
   debugEcho "referenceTreeFile = $referenceTreeFile"
   debugEcho "tempSampleTreeFile = $tempSampleTreeFile"
   debugEcho "tempSampleGrunTreeFile = $tempSampleGrunTreeFile"
   debugEcho "tempReferenceGrunTreeFile = $tempReferenceGrunTreeFile"
   
   # finally test the sample
   
   grun -cp "$parserPath" $reduceTreeArg CSharp prog "$sampleSource" -tree >"$tempSampleTreeFile" 2>"$tempStdErrFile"
   local exitStatus=$?
   
   # "isEmpty" means non-existant or empty
   isEmptyRefStdErr=`[ ! -s "$referenceStdErrFile" ] && echo true || echo false`
   isEmptyTempStdErr=`[ ! -s "$tempStdErrFile" ] && echo true || echo false`
   
   if  [ $exitStatus != 0 ]; then
      # grun failed – test FAILED
      return $exitStatus 
   else
      # check stderr
      if [ $isEmptyTempStdErr == true ]; then
         # no errors produced by test
         if [ $isEmptyRefStdErr == false ]; then
            # errors expected, bad
            errorEcho "Sample should have produced parsing/semantic errors, it did not"
            return -1
         fi
         # both files empty => pass
      else
         # errors produced by test
         if [ $isEmptyRefStdErr == true ]; then
            # no errors expected, bad
            errorEcho "Sample produced parsing/semantic errors, it should not"
            return -1
         fi
         # both file non-empty, diff
         diff "$tempStdErrFile" "$referenceStdErrFile"
         exitStatus=$?
         if [ $exitStatus != 0 ]; then
            return $exitStatus
         fi
         # files equal -> pass
      fi
   
      # why the cascade? bash – saves run, save $?, if/return
   
      if grun -cp "$grunTreePath" GrunTree tokens "$tempSampleTreeFile" >"$tempSampleGrunTreeFile"; then
         if grun -cp "$grunTreePath" GrunTree tokens "$referenceTreeFile" >"$tempReferenceGrunTreeFile"; then
            if diff "$tempSampleGrunTreeFile" "$tempReferenceGrunTreeFile"; then
              return 0
            else
               return $?
            fi
         else
            return $?
         fi
      else
         return $?
      fi
   fi
}
