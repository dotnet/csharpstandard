lexer grammar GrunTree;

@lexer::members
{
   int indent = 0;
   String pad = "⎜ ";

   void padding()
   {
      String indentation = pad.repeat(indent);
      System.out.print(indentation);
   }
}

// grun tree output uses ( & ) to surround tree nodes *and* source ( & ) in the grammar
// unadorned, by observation the following are source ():
//   ( followed by a space
//   ) preceded by a space
//   ( ) separated by a space (two source tokens)
// and any other ()s delimit nodes

LRParen : '( )' { padding(); System.out.println("("); padding(); System.out.println(")"); } ;
LParen : '( ' { padding(); System.out.println("("); } ;
RParen : ' )' { padding(); System.out.println(")"); } ;

NodeOpen : '(' { padding(); System.out.println("⎛"); indent++; } ;
NodeClose : ')' { indent--; padding(); System.out.println("⎝"); } ;

WhiteSpace : [\p{White_Space}] -> skip ;

StringDQ : '"' (~["\\]|'\\'.)* '"'            { padding(); System.out.println(getText()); } ;
StringSQ : '\'' (~['\\]|'\\'.)* '\''         { padding(); System.out.println(getText()); } ;
InterpolatedPart : '〔' (~[〕]|'〕〕')* '〕' { padding(); System.out.println(getText()); } ; 

Atom : ~["'()\p{White_Space}]+              { padding(); System.out.println(getText()); } ;