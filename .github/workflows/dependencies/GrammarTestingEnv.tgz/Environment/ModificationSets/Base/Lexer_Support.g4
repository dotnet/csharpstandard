lexer grammar Lexer_Support;

/* Important:
 *
 * This is just sample support code, it is not intended for inclusion in the
 * Standard or for distribution beyond TG2.
 *
 * The code works, no effort has gone into making it good, pretty or elegant!
 *
 * private is used to mark declarations not meant to be used outside this file
 *
 */

@lexer::header
{
	import java.util.List;
	import java.util.ArrayList;
	import java.util.Arrays;
	import java.util.HashSet;
	import java.util.Set;
	import java.util.Stack;
	import java.util.function.Function;
	import java.util.function.Supplier;
	import java.util.regex.MatchResult;
	import java.util.regex.Matcher;
	import java.util.regex.Pattern;
}

@lexer::members
{
   // These two methods enhance the mode stack by providing a peek operation
   // and making the stack “bottomless” so mismatched brackets don’t cause
   // a stack underflow and are passed to the parser to report as syntax errors.
   
	// There is pushMode, popMode, and _mode (currentMode) but no peekMode...
	public int peekMode()
	{
	   // if there is nothing to peek just return DEFAULT_MODE
	   return _modeStack.isEmpty() ? DEFAULT_MODE : _modeStack.peek();
	}
	
	// override popMode() to make it a bottomless stack
	public int popMode()
	{
	   if ( _modeStack.isEmpty() )
	   {
	      System.out.println("unbalanced ()/{}/[]");
	      return DEFAULT_MODE; 
	   }
	   return super.popMode();
	}
	
	// convenience methods to reduce code in generated .g4 files
	public boolean peekModeIs(int mode) { return peekMode() == mode; }
	
	public boolean lookAheadIs(int pos, int value) { return _input.LA(pos) == value; }
	public boolean lookAheadIsNot(int pos, int value) { return _input.LA(pos) != value; }
	
	public void wrapToken() { setText("〔" + getText().replaceAll("〕", "〕〕") + "〕"); }
}
