parser grammar Parser_Support;

/* Important:
 *
 * This is just sample support code, it is not intended for inclusion in the
 * Standard or for distribution beyond TG2.
 *
 * The code works, no effort has gone into making it good, pretty or elegant!
 *
 * private is used to mark declarations not meant to be used outside this file
 *
 */

@parser::header
{
	import java.util.List;
	import java.util.ArrayList;
	import java.util.Arrays;
	import java.util.HashSet;
	import java.util.Set;
	import java.util.Stack;
	import java.util.function.Function;
	import java.util.function.Supplier;
	import java.util.function.Consumer;
	import java.util.regex.MatchResult;
	import java.util.regex.Matcher;
	import java.util.regex.Pattern;
}

@parser::members
{
   void notifySemanticError(int line, int charPositionInLine, String msg)
   {
		ANTLRErrorListener listener = getErrorListenerDispatch();
		listener.syntaxError(this, null, line, charPositionInLine, msg, null);
   }

//======================================================================================

	// convenience methods to reduce code in generated .g4 files
	public boolean lookAheadIs(int pos, int value) { return _input.LA(pos) == value; }
	public boolean lookAheadIsNot(int pos, int value) { return _input.LA(pos) != value; }

   // action to
   // • remove empty type_argument_list node
   // • reduce the depth of tree by dropping intermediate nodes

   public void reduceTree(ParserRuleContext currentctx)
   {
      // remove empty type_argument_list nodes that are artifacts of the
      // disambiguation predicate

      class TakeOutTheEmpties
      {
         public void accept(ParseTree node)
         {
            if ( node instanceof ParserRuleContext )
            {
               ParserRuleContext parent = (ParserRuleContext)node;
         
               int childCount = parent.getChildCount();
               
               if (childCount == 0) return;
               
               List<ParseTree> children = parent.children;
               
               // process childen from last to first so we can easily remove any
               for(int ix = childCount-1; ix >= 0; ix--)
               {
                  ParseTree anyTarget = children.get(ix);
                  
                  if(anyTarget instanceof ParserRuleContext)
                  {
                     ParserRuleContext childTarget = (ParserRuleContext)anyTarget;
                     
                     if( childTarget.getRuleIndex() == RULE_type_argument_list
                         && childTarget.getChildCount() == 0
                       )
                     {
                        // empty type_argument_list -> remove it
                        children.remove(ix);
                     }
                     else
                     {
                        // anything else – scan down and take out the empties
                        accept(childTarget);
                     }
                  }
               }
            }
         }
      };
      
      (new TakeOutTheEmpties()).accept(currentctx);
      
      //=================================================================================
      
      // reduce the depth of tree by dropping intermediate nodes
      // with one parent and one child, e.g. A->B->C to A->C. Deletes
      // runs of such nodes by doing depth first removal, e.g. A->B->C->D
      // => A->B->D => A->D as the Reducer returns up the tree
      
      String reduceProperty = System.getProperty("reduceTree", "no").toLowerCase();
      if (!reduceProperty.equals("yes")) return;

      String reduceAllChildrenProperty = System.getProperty("reduceAllChildren", "no").toLowerCase();
      boolean reduceAllChildren = reduceAllChildrenProperty.equals("yes");
      
      class Reducer implements Consumer<ParseTree>
      {
         public void accept(ParseTree node)
         {
            if ( node instanceof ParserRuleContext )
            {
               ParserRuleContext parent = (ParserRuleContext)node;
         
               if (parent.getChildCount() == 0) return;

               // transform depth first
               parent.children.forEach(this);
               
               // reduce depth
               if (reduceAllChildren || parent.getChildCount() == 1)
                  parent.children.replaceAll(child ->
                     {
                        if (child instanceof ParserRuleContext)
                        {
                           ParserRuleContext childNode = (ParserRuleContext)child;
                           
                           if (childNode.getChildCount() == 1) // a single grandchild
                           {
                              ParseTree grandchild = childNode.getChild(0);
                              
                              if(grandchild instanceof ParserRuleContext)
                              {
                                 ParserRuleContext grandchildNode = (ParserRuleContext)grandchild;
                                 
                                 // bye bye child
                                 grandchildNode.setParent(parent);
                                 return grandchildNode;
                              }
                           }
                        }
                        return child;
                     }
                  );
            }
            return;
         }
      };
      
      if (currentctx.children != null)
         currentctx.children.forEach(new Reducer());
   }

//======================================================================================

   // Actions to “undo” MLR inlining
   // This collection collection of actions move all the current children of the
   // passed context into a child context of the specified kind, thereby inserting
   // the nodes that grammar specifies and would have existed if Antlr handled MLR
   private void insertNode(ParserRuleContext currentctx, ParserRuleContext insertedctx)
   {
      insertedctx.children = new ArrayList<>(currentctx.children);
      insertedctx.children.forEach(child -> { if (child instanceof ParserRuleContext) ((ParserRuleContext)child).setParent(insertedctx); });
      currentctx.children.clear();
      currentctx.addChild(insertedctx);
   }
   
   public void asInvocationExpression(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Invocation_expressionContext(currentctx, currentctx.invokingState));
   }

   public void asElementAccess(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Element_accessContext(currentctx, currentctx.invokingState));
   }

   public void asMemberAccess(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Member_accessContext(currentctx, currentctx.invokingState));
   }

   public void asNullConditionalMemberAccess(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Null_conditional_member_accessContext(currentctx, currentctx.invokingState));
   }

   public void asNullConditionalElementAccess(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Null_conditional_element_accessContext(currentctx, currentctx.invokingState));
   }

   public void asPostIncrementExpression(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Post_increment_expressionContext(currentctx, currentctx.invokingState));
   }

   public void asPostDecrementExpression(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Post_decrement_expressionContext(currentctx, currentctx.invokingState));
   }

   public void asNullForgivingExpression(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Null_forgiving_expressionContext(currentctx, currentctx.invokingState));
   }

   public void asPointerMemberAccess(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Pointer_member_accessContext(currentctx, currentctx.invokingState));
   }

//======================================================================================

   // This action reports the semantic restriction of applying element access in §12.8.11-2

   void elementAccessSemanticCheck(ParserRuleContext currentctx)
   {
      int ruleIndex = currentctx.getRuleIndex();
      int childCount = currentctx.getChildCount();

      // Due to MLR and post-MLR fixup we should be looking at a primary_expression with
      // element_access/null_conditional_member_access/pointer_element_access as its sole child
      if (ruleIndex != RULE_primary_expression || childCount != 1)
         return; // should not happen, so no semantic check to do!

      // get the child
      ParseTree childTree = currentctx.getChild(0);
      
      if ( !(childTree instanceof ParserRuleContext) )
         return; // should not happen, so no semantic check to do!

      ParserRuleContext childRule = (ParserRuleContext)childTree;
      int childRuleIndex = childRule.getRuleIndex();
      int childChildCount = childRule.getChildCount();
      
      // confirm child is one of the types we expect
      switch (childRuleIndex)
      {
         case RULE_element_access:
         case RULE_pointer_element_access:
            if (childChildCount != 4)
               return;  // wrong number of children, no semantic check to do
            break;
         case RULE_null_conditional_element_access:
            if (childChildCount != 5)
               return;  // wrong number of children, no semantic check to do
            break;
         default:
            return; // not an access, no semantic check to do
      }
      
      ParseTree accessTargetTree = childRule.getChild(0);
      ParseTree tokenForErrorMessageLocation = childRule.getChild(1);
      
      if ( !(accessTargetTree instanceof ParserRuleContext) )
         return;  // should not happen, so no semantic check to do!
      
      ParserRuleContext accessTarget = (ParserRuleContext)accessTargetTree;
      int accessRuleIndex = accessTarget.getRuleIndex();
      int accessChildCount = accessTarget.getChildCount();
      
      if (accessRuleIndex != RULE_primary_expression || accessChildCount == 0)
         return;  // cannot be a primary_expression which is an array_creation_expression or stackalloc_expression, so no semantic check to do!
      
      // get child of the primary_expression
      ParseTree lhsTargetTree = accessTarget.getChild(0);
      
      if ( !(lhsTargetTree instanceof ParserRuleContext) )
         return;  // should not happen, so no semantic check to do!
      
      ParserRuleContext lhsTarget = (ParserRuleContext)lhsTargetTree;
      int lhsRuleIndex = lhsTarget.getRuleIndex();
      
      switch (lhsRuleIndex)
      {
         case RULE_array_creation_expression:
         case RULE_stackalloc_expression:
            break;
         default:
            return; // not a creation expression, so no semantic check to do
      }

      // almost there, check the trailing token of lhsTarget
      
      Token lhsLast = lhsTarget.getStop();
      int lhsLastType = lhsLast.getType();
      String lhsLastText = lhsLast.getText();
      
      if (lhsLastType == TK_RBRACE)
         return; // there is an initialiser, semantic check passes
      
      if (lhsLastType != TK_RBRACK)
      {
         System.err.println(String.format("%d:%d Error: Unexpected LHS last token %s (%d).", lhsLast.getLine(), lhsLast.getCharPositionInLine(), lhsLastText, lhsLastType));
         return;
      }
      
      // semantic test has failed, produce error message
      
      Token reportAt = tokenForErrorMessageLocation instanceof TerminalNodeImpl ? ((TerminalNodeImpl)tokenForErrorMessageLocation).getSymbol() : lhsLast;
      String childRuleName = ruleNames[childRuleIndex];
      String childRuleNamePrefix = "AEIOUaeiou".indexOf(childRuleName.charAt(0)) != -1 ? "an" : "a";
      String lhsRuleName = ruleNames[lhsRuleIndex];
      String lhsRuleNamePrefix = "AEIOUaeiou".indexOf(lhsRuleName.charAt(0)) != -1 ? "an" : "a";

      notifySemanticError(reportAt.getLine(),
                          reportAt.getCharPositionInLine(),
                          String.format("LHS of %s %s cannot be %s %s unless it has an initializer", childRuleNamePrefix, childRuleName, lhsRuleNamePrefix, lhsRuleName)
                         );


   }
}
