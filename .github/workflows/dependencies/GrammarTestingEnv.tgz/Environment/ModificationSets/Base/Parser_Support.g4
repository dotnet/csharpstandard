parser grammar Parser_Support;

/* Important:
 *
 * This is just sample support code, it is not intended for inclusion in the
 * Standard or for distribution beyond TG2.
 *
 * The code works, no effort has gone into making it good, pretty or elegant!
 *
 * private is used to mark declarations not meant to be used outside this file
 *
 */

@parser::header
{
	import java.util.List;
	import java.util.ArrayList;
	import java.util.Arrays;
	import java.util.HashSet;
	import java.util.Set;
	import java.util.Stack;
	import java.util.function.Function;
	import java.util.function.Supplier;
	import java.util.function.Consumer;
	import java.util.regex.MatchResult;
	import java.util.regex.Matcher;
	import java.util.regex.Pattern;
}

@parser::members
{
	// convenience methods to reduce code in generated .g4 files
	public boolean lookAheadIs(int pos, int value) { return _input.LA(pos) == value; }
	public boolean lookAheadIsNot(int pos, int value) { return _input.LA(pos) != value; }

   // action to
   // • remove empty type_argument_list node
   // • reduce the depth of tree by dropping intermediate nodes

   public void reduceTree(ParserRuleContext currentctx)
   {
      // remove empty type_argument_list nodes that are artifacts of the
      // disambiguation predicate

      class TakeOutTheEmpties
      {
         public void accept(ParseTree node)
         {
            if ( node instanceof ParserRuleContext )
            {
               ParserRuleContext parent = (ParserRuleContext)node;
         
               int childCount = parent.getChildCount();
               
               if (childCount == 0) return;
               
               List<ParseTree> children = parent.children;
               
               // process childen from last to first so we can easily remove any
               for(int ix = childCount-1; ix >= 0; ix--)
               {
                  ParseTree anyTarget = children.get(ix);
                  
                  if(anyTarget instanceof ParserRuleContext)
                  {
                     ParserRuleContext childTarget = (ParserRuleContext)anyTarget;
                     
                     if( childTarget.getRuleIndex() == RULE_type_argument_list
                         && childTarget.getChildCount() == 0
                       )
                     {
                        // empty type_argument_list -> remove it
                        children.remove(ix);
                     }
                     else
                     {
                        // anything else – scan down and take out the empties
                        accept(childTarget);
                     }
                  }
               }
            }
         }
      };
      
      (new TakeOutTheEmpties()).accept(currentctx);
      
      //=================================================================================
      
      // reduce the depth of tree by dropping intermediate nodes
      // with one parent and one child, e.g. A->B->C to A->C. Deletes
      // runs of such nodes by doing depth first removal, e.g. A->B->C->D
      // => A->B->D => A->D as the Reducer returns up the tree
      
      String reduceProperty = System.getProperty("reduceTree", "no").toLowerCase();
      if (!reduceProperty.equals("yes")) return;

      String reduceAllChildrenProperty = System.getProperty("reduceAllChildren", "no").toLowerCase();
      boolean reduceAllChildren = reduceAllChildrenProperty.equals("yes");
      
      class Reducer implements Consumer<ParseTree>
      {
         public void accept(ParseTree node)
         {
            if ( node instanceof ParserRuleContext )
            {
               ParserRuleContext parent = (ParserRuleContext)node;
         
               if (parent.getChildCount() == 0) return;

               // transform depth first
               parent.children.forEach(this);
               
               // reduce depth
               if (reduceAllChildren || parent.getChildCount() == 1)
                  parent.children.replaceAll(child ->
                     {
                        if (child instanceof ParserRuleContext)
                        {
                           ParserRuleContext childNode = (ParserRuleContext)child;
                           
                           if (childNode.getChildCount() == 1) // a single grandchild
                           {
                              ParseTree grandchild = childNode.getChild(0);
                              
                              if(grandchild instanceof ParserRuleContext)
                              {
                                 ParserRuleContext grandchildNode = (ParserRuleContext)grandchild;
                                 
                                 // bye bye child
                                 grandchildNode.setParent(parent);
                                 return grandchildNode;
                              }
                           }
                        }
                        return child;
                     }
                  );
            }
            return;
         }
      };
      
      if (currentctx.children != null)
         currentctx.children.forEach(new Reducer());
   }

   // Actions to “undo” MLR inlining
   // This collection collection of actions move all the current children of the
   // passed context into a child context of the specified kind, thereby inserting
   // the nodes that grammar specifies and would have existed if Antlr handled MLR
   private void insertNode(ParserRuleContext currentctx, ParserRuleContext insertedctx)
   {
      insertedctx.children = new ArrayList<>(currentctx.children);
      insertedctx.children.forEach(child -> { if (child instanceof ParserRuleContext) ((ParserRuleContext)child).setParent(insertedctx); });
      currentctx.children.clear();
      currentctx.addChild(insertedctx);
   }
   
   public void asPrimaryExpression(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Primary_expressionContext(currentctx, currentctx.invokingState));
   }

   public void asInvocationExpression(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Invocation_expressionContext(currentctx, currentctx.invokingState));
   }

   public void asElementAccess(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Element_accessContext(currentctx, currentctx.invokingState));
   }

   public void asMemberAccess(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Member_accessContext(currentctx, currentctx.invokingState));
   }

   public void asNullConditionalMemberAccess(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Null_conditional_member_accessContext(currentctx, currentctx.invokingState));
   }

   public void asNullConditionalElementAccess(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Null_conditional_element_accessContext(currentctx, currentctx.invokingState));
   }

   public void asPostIncrementExpression(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Post_increment_expressionContext(currentctx, currentctx.invokingState));
   }

   public void asPostDecrementExpression(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Post_decrement_expressionContext(currentctx, currentctx.invokingState));
   }

   public void asNullForgivingExpression(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Null_forgiving_expressionContext(currentctx, currentctx.invokingState));
   }

   public void asPointerMemberAccess(ParserRuleContext currentctx)
   {
      insertNode(currentctx, new Pointer_member_accessContext(currentctx, currentctx.invokingState));
   }
}
