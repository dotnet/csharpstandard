# Interpolated Strings

These additions modify the interpolated strings grammar as follows:

- ANTLR lexical modes are utilised to track whether the lexer is tokenising outside of
a interpolated string, inside one, an expression embedded in one, an interpolated string
inside an expression inside an interpolated string, etc.

- ANTLR lookahead is used to implement the semantic rules specified in the Standard. To keep
the rules east to read macros are used to implement lookahead, the definitions are in the file “Macros.json”.

- The default ANTLR mode stack only supports push and pop operations, a mode stack peek
operation is added to support the semantic rules for parsing interpolation formats. This
is implemented by both a macro (“Macros.json”) and target language support code specified in ANTLR
(“Lexer_Support.g4”)

Note that none of these additions modify the grammar in the Standard *per se*, they simply
use ANTLR features to enforce the semantic rules in the Standard.

#### Overview of strategy

ANTLR lexical grammars support modes and a mode stack allowing the lexer to push to a new mode, with tokenising
rules for that mode, and then later pop back to the previous mode.

The lexer starts in `DEFAULT_MODE`, on starting to tokenise an interpolated or verbatim interpolated
string the additions below push to mode `IRS_CONT`/`IVS_CONT`, for regular and verbatim interpolated strings
respectively, at the end of tokenising the string the original mode is popped back.

On encountering a nested expression while in the `IRS_CONT`/`IVS_CONT` mode the additions push to
`DEFUALT_MODE` to continue tokenising; and now in `DEFAULT_MODE` again if another
interpolated string is encountered nested inside the original one, the additions push the an interpolated mode again, etc.

To support this process the additions also count all bracket forms – parentheses, square and brace –
so braces surrounding expressions within interpolated strings can be correctly matched.
A real lexer might do this by actually counting the brackets, in this simple version the ANTLR
mode stack is used by pushing to/popping from `DEFAULT_MODE`.

#### Dealing with `grun`

When outputting a tree dump the `grun` (aka `TestRig`) tool assumes that the lexical syntax
of parse tree tokens allows them to printed out space separated without any added delimited
(as as quotes).

The C# interpolated string grammar breaks those assumptions meaning the tree output is
difficult/impossible to parse automatically.

Interpolated strings are recognised as a collection of fragments by the C# grammar.
Each fragment, being just part of the original string, is not lexically a string itself.
This means that the tokens for these fragments don't have defined
start/end markers and may contain any character including whitespace.

The `WrapToken` (“Macros.json”) macro wraps a token it is applied to in tortoise brackets, 〔 and 〕, 
enabling parsing of the tree output.

This modification is purely “cosmetic” and has no impact on how C# is lexed, parsed, or the shape of
the tree produced by `grun` – it just decorates the textual content of a few lexical tokens.
The modification is visible in the tree, token and graph `grun` outputs.

Another issue with the tree output is it is one long line of Lisp-like output, comparing
trees is a challenge and `diff` is effectively useless.

The `GrunTree.g4` grammar parses the decorated tree output and pretty prints it out in
a human readable form which can easily compared using `diff`.

### 6.3.0 Extracted literal tokens

These additions support the “counting” of brackets:

```ANTLR
TK_LPAREN : '(' -> pushMode(DEFAULT_MODE) ;
TK_RPAREN : ')' -> popMode ;
TK_LBRACK : '[' -> pushMode(DEFAULT_MODE) ;
TK_RBRACK : ']' -> popMode ;
TK_LBRACE : '{' -> pushMode(DEFAULT_MODE) ;
TK_RBRACE : '}' -> popMode ;
```

### 6.4.1 General

For completeness we add the interpolated string tokens:

```ANTLR
# Modify
token
    : identifier
    | keyword
    | Integer_Literal
    | Real_Literal
    | Character_Literal
    | String_Literal
    | operator_or_punctuator
    // interpolated string parts
    | Interpolated_Regular_String_Start
    | Regular_Interpolation_Format
    | Interpolated_Regular_String_Mid
    | Interpolated_Regular_String_End
    | Interpolated_Verbatim_String_Start
    | Verbatim_Interpolation_Format
    | Interpolated_Verbatim_String_Mid
    | Interpolated_Verbatim_String_End
    ;
```

### 12.8.3 Interpolated String Expressions

These additions modify lexer rules to switch between normal and
interpolated string lexer modes and place the original rules into the
appropriate mode:

```ANTLR
# Modify
Interpolated_Regular_String_Start
    : '$"' WrapToken«» -> pushMode(IRS_CONT)
    ;

# Modify
Regular_Interpolation_Format
    : ':' Interpolated_Regular_String_Element+ LookAheadIs«'}'» PeekModeIs«IRS_CONT» WrapToken«»
    ;

mode IRS_CONT;

# Modify
Interpolated_Regular_String_Mid
    : Interpolated_Regular_String_Element+ WrapToken«»
    ;

# Add
Interpolated_Regular_Solitary_LBrace
    : LookAheadIsNot«2, '{'» '{' -> type(TK_LBRACE), pushMode(DEFAULT_MODE)
    ;

# Modify
Interpolated_Regular_String_End
    : '"' WrapToken«» -> popMode
    ;

mode DEFAULT_MODE;

/********************************************************************************************/

# Modify
Interpolated_Verbatim_String_Start
    : ( '$@"'
      | '@$"'
      ) WrapToken«» -> pushMode(IVS_CONT)
    ;

# Modify
Verbatim_Interpolation_Format
    : ':' Interpolated_Verbatim_String_Element+  LookAheadIs«'}'» PeekModeIs«IVS_CONT» WrapToken«»
    ;

mode IVS_CONT;

# Modify
Interpolated_Verbatim_String_Mid
    : Interpolated_Verbatim_String_Element+ WrapToken«»
    ;

# Add
Interpolated_Verbatim_Solitary_LBrace
    : LookAheadIsNot«2, '{'» '{' -> type(TK_LBRACE), pushMode(DEFAULT_MODE)
    ;

# Modify
Interpolated_Verbatim_String_End
    : '"' WrapToken«» -> popMode
    ;
```