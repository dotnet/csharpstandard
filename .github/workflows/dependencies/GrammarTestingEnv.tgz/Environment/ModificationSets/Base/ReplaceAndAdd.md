## Preface

This file is a “replacement & additions” file, which is part of a “modification set”, used by something called `BuildGrammar`. Some introductory material is probably required…

### BuildGrammar

`BuildGrammar` is a custom tool used to extract grammar from the Standard’s source (`.md` files, best supplied in a directory), apply any specified changes (see *Modification Sets* below), and produce separate ANTLR lexer and parser grammars (usually `CSharpLexer.g4` and `CSharpParser.g4`) along with any support files containing custom code in ANTLR format (`.g4`).

`BuildGrammar` locates the grammar in the Standard’s source by looking for code blocks tagged with `ANTLR`. While doing this it also notes the section numbers so rules in the extracted grammar are associated with their source by section number comments. This is the same process as the grammar extraction tool that builds the Standard’s *Annex A* uses.

`BuildGrammar` does some further processing on the extracted grammar, such as detecting literals used and declaring explicit tokens for them. This process is usually done silently by ANTLR but by doing it itself the tokens are given usable names and their rules can later be modified by a modification set – for example, this is done by the Base modification set when making the grammar for interpolated strings function correctly in ANTLR.

> ---
> *Note*: `BuildGrammar`, like with the grammar extractor use to build Annex A of the Standard, does not parse the ANTLR grammar *per se*. It only recognises the basic rule structure, identifies the rule name, and treats the rest of the rule more-or-less as a blob (though it does support text-based macro expansion of that blob).

> This means that it is limited in what it can do, e.g.: “modifying” a rule means replacing one blob with another; the MLR removal is not automated; etc.

> To do more than blob processing would be a lot of work, probably based off a fork on ANTLR itself… There are *__NO__* plans to do this!

> ---

### Modification Sets

A *modification set* is a collection of “replacements and additions” (`.md`), macros (`.json`), and support code (`.g4`) files located together in a directory named after the modification set (in this case `Base`).

A modification set is applied by `BuildGrammar` to the grammar extract from the Standard to produce a working grammar which can be verified or used to build a parser which can be used for testing language samples against the Standard’s grammar.

A modification set is written relative to a *baseline grammar*, this is the grammar in the Standard as it existed when a modification set was authored. A baseline grammar is produced using `BuildGrammar` *without* specifying any modification set or files – it is the grammar extracted as-is from the Standard source.

Baseline grammars are contained in a directory `BaselineGrammar` either located inside the modification sets own directory (for a private baseline) or in sibling directory of the modification set directory (for a baseline shared by multiple modification sets).

### File Formats

#### Replacements & Additions (`.md`)

This “replacements & additions” file is a standard `.md` file, similar to the source of the Standard.

ANTLR rules are extracted based on being in `` ```ANTLR … ``` `` code blocks. To include
grammar samples in the file which will not be extracted by `BuildGrammar` simply omit the
`ANTLR` tag on the code block.

The code blocks in a replacement & additions file are *tagged*,* unlike those in files containing the Standard source. These tags describe what the rule is and help improve the robustness of applying changes for testing purposes as the source of the Standard evolves.

A tag is a line of the form `# <tag>` immediately before the rule name, an example (taken from below):

```
      # Modify
      Comment
          : ( Single_Line_Comment
            | Delimited_Comment
            ) -> skip
          ;
```

This rule is designed to `Modify` and existing rule, in this case the ANTLR instruction `skip` is added so that comments are not included in the parse tree.

The defined tags are:

> `Add`
>> The rule is an addition. `BuildGrammar` will check that the rule does not already exist in the grammar extracted from the Standard.

> `Modify`
>> The rule is a modification. `BuildGrammar` will compare the rule in the extracted grammar to the rule in the baseline grammar to confirm that it has not changed
>> since the modification was written. If the two are the same the modification rule replaces the one in the extracted grammar.

> `Expect` & `ReplaceWith`
>> This is a pair of tagged rules, written consecutively. The first tagged `Expect` is the rule as it is expected to exist in the extracted grammar, the second tagged `ReplaceWith` is its replacement. `BuildGrammar` does the comparison between the expected and extracted rules and if successful performs the replacement.

>> This pair of tagged rules does not use the baseline grammar, unlike `Modify`. It exists for cases where the Standard has evolved, the extracted grammar has some (minor) change to a rule or has added a rule, and the modification is required for this modification set.

>> Further a modification set can contain multiple replacements & additions files which build upon each other, in this case the modification in a latter file may need to modify one applied by an earlier file and so the latter needs to `Expect` what the former produced… If this doesn’t make any sense either don’t worry or see the demo sample `Nameof (nameof_expresssion)`.

The Standard’s source `.md` files contain no tags, for these `BuildGrammar` assumes `Add` and so checks as it extracts the grammar that no rule is defined twice…

#### Macros (`.json`)

Macros are defined in JSON files, the structure of which is described in the `Macros.json` file which is part of this Base modification set.

A modification set may contain multiple macro files.


#### Support Code (`.g4`)

A support code file is an ANTLR `.g4` file following ANTLR conventions for including code.

A modification set may contain multiple support code files, the contents of each is collated together to produce up to two support code files, one each for the lexer and parser.

---

### File List

This set consists of:

1. `_Modifications_Order_.txt` – This file is the index of modification set and contains the names of the following files, one per line, in the order described. The order of applying replacement & additions files can be significant so `BuildGrammar` uses this file to obtain the order.
1. `ReplaceAndAdd.md` – This file, the main replacements & additions.
1. `InterpolatedSupport.md` – Replacements & additions to convert the context sensitive interpolated strings grammar into one using ANTLR lexical modes.
1. `Macros.json` – Macros used in the replacement & additions files. These largely interface between the grammar rules and the custom code in the next two files.
1. `Lexer_Support.g4` – Custom code to support the lexer.
1. `Parser_Support.g4` – As previous but for the parser.

There is no baseline grammar in the modification set, it uses the baseline grammar in it’s sibling `BaselineGrammar` directory.

---
---

# Base Modification Set

## Contents

This modification set includes changes to:

- allow the grammar to actually run (unlike the *VerifyOnly* set that allows it to *verify*);
- skip whitespace;
- recognize but otherwise ignore preprocessor directives;
- handle interpolated strings through the use of lexical modes;
- fixup attribute argument recognition so that named arguments occur in the parse tree and are not subsumed by positional ones;
- perform a semantic check on the element access rules;
- conver the MLR in the grammar to simple LR so that ANTLR can handle it;
- “undo” the MLR removal by adding back to the constructed parse tree any nodes MLR elided; and
- optionally reduce the tree by eliding middle nodes in single parent/child runs, e.g. A => B => C => D becomes A => D.

The resultant lexer and parser can be used to exercise the grammar against sample code
to determine that the expected program structure (parse tree) is produced by the Standard’s grammar.

The optional tree reduction is controlled by Java properties and is supported by the provided tools.

---

## Top Level Rule

The Standard’s *compilation_unit* allows ANTLR to ignore garbage at the end of a file, this
added rule has an EOF requirement to ensure the whole of the input must be a correct program.

The rule also exists as a place to attach the macro `ReduceTree«»`; this macro calls code
which reduces the size of the tree by removing unneeded chains of single parent/child nodes.

> *Note: The section number makes this the first rule in the grammar, not required but it
has to go somewhere…*

### 0.0.0 Top Level Rule

```ANTLR
// [ADDED] Rule added as the start point
# Add
prog: compilation_unit LookAheadIs«EOF» ReduceTree«»;
```
---

## Discarding Whitespace

The following changes in §6.3.2, §6.3.3 and §6.3.4, add `-> skip` to the “whitespace”
token rules so that are not passed to the parser. This behaviour is implicit in the
Standard.

### 6.3.2 Line terminators

```ANTLR
// [SKIP]
# Modify
New_Line
    : ( New_Line_Character
      | '\u000D\u000A'    // carriage return, line feed
      ) -> skip
    ;
```

### 6.3.3 Comments

```ANTLR
// [SKIP]
# Modify
Comment
    : ( Single_Line_Comment
      | Delimited_Comment
      ) -> skip
    ;
```

### 6.3.4 White space

```ANTLR
// [SKIP]
# Modify
Whitespace
    : ( [\p{Zs}]  // any character with Unicode class Zs
      | '\u0009'  // horizontal tab
      | '\u000B'  // vertical tab
      | '\u000C'  // form feed
      ) -> skip
    ;

```

---

## Discarding Pre-processing Directives

This change causes all pre-processor directives to be skipped like whitespace. (Another
modification set contains a working implementation of the pre-processor so samples
containing directives can be checked.)

### 6.5.1 General

```ANTLR
// [SKIP]
# Modify
PP_Directive
    : (PP_Start PP_Kind PP_New_Line) -> skip
    ;
```

---

## Semantic Check on Element Access Rules

Alongside the C# grammar the Standard includes some additional semantic checks on
some rules, some of these are implemented by the modification set *Rules* which inherits
from this one.

However one semantic check, using the macro `ElementAccessSemanticCheck«»`,
on the *element_access*, *null_conditional_element_access* and (effectively) *pointer_element_access*
rules is implemented here. Adding the macro call is incorporated in the MLR changes below.
See `Parser_Support.g4` for the details of the check itself.

This is included here to save modifying *primary_expression* again in *Rules*, where other such checks
are implemented.

---

## Mutual Left Recursion Removal

Mutual left recursive (MLR) of rules is not supported by ANTLR, a grammar with MLR
will be rejected.

All but one MLR group has been removed from the grammar (and we should
strive not to introduce any new ones).

This change resolves the one remaining MLR group by inlining some of the non-terminal
alternatives in *primary_expression*.

With this change the grammar is accepted by ANTLR.

### The MLR in the Standard

Consider the following abbreviated extract:

```
      // Source: §12.8.1 General
      primary_expression
          : ...
          | post_increment_expression
          | ...
          ;

      // Source: §12.8.15 Postfix increment and decrement operators
      post_increment_expression
          : primary_expression '++'
          ;
```

This contains the MLR cycle:

```
      *primary_expression*
      -> *post_increment_expression*
      -> *primary_expression*
      -> ...
```

To resolve this *post_increment_expression* can be inlined in *primary expression* resulting in:

```
      primary_expression
          : ...
          // From: post_increment_expression
             | primary_expression '++'
          | ...
          ;
```

This is still left recursive (LR), which ANTLR supports, but there is no MLR. This process
is repeated for all the MLR rules.

The inlined rules are **not** removed as they maybe referenced elsewhere in the grammar,
however there is a use for any orphaned ones as well…

### It Works But…

The above process works, MLR is removed, the language is parsed. However in achieving this
the rule *post_increment_expression* is no longer directly represented in the parse tree
below *primary_xpression*, just its contents.

While this is no big issue for a *compiler* processing the parse tree; for people viewing
the tree, say in a graphical tool like `grun`, those elided nodes don’t help.

So we put them back… using ANTLR *actions*.

A number of `BuildGrammar` macros are defined of the form `As`*`RuleName`*`«»`, e.g. `AsPostIncrementExpression«»`. These macros expand to ANTLR actions which call custom code (in `ParserSupport.g4`) which inserts the nodes elided by MLR removal.
The example above becomes:

```
      primary_expression
          : ...
          // From: post_increment_expression
             | primary_expression '++' AsPostIncrementExpression«»
          | ...
          ;
```

Now both ANTLR and people (we hope) are happy.

### Finally The Big Ugly Change

MLR removal has not been done in Standard itself as it makes *primary_expression*
“uglier”, even without the node insertion macros, and would obfuscate somewhat the description in the Standard – both
subjective reasons of course...

Remember that MLR is not supported by ANTLR and so without this change the grammar would be rejected – and therefore no validation or testing would be possible, so ugly it is!

Combined with this MLR change is a small one for *parenthesized_expression* and *tuple_expression*,
the order of these two is switched so the latter comes first. Without this swap ANTLR can make the
wrong choice and report a syntax error when trying to parse a tuple.

### 12.8.1 General

```ANTLR
// [CHANGE] This removes a mutual left-recursion group which has been left in the Standard
// [CHANGE] (other uses of MLR have been removed). Without this change the grammar will fail
// [CHANGE] to verify and no sample testing can be done.
# Modify
primary_expression
    : literal
    | interpolated_string_expression
    | simple_name
    | tuple_expression
    | parenthesized_expression
    // From: member_access
        | primary_expression '.' identifier type_argument_list? AsMemberAccess«»
        | predefined_type '.' identifier type_argument_list? AsMemberAccess«»
        | qualified_alias_member '.' identifier type_argument_list? AsMemberAccess«»
    // From: null_conditional_member_access
    	| primary_expression '?' '.' identifier type_argument_list? (null_forgiving_operator? dependent_access)* AsNullConditionalMemberAccess«»
    // From: invocation_expression
        | primary_expression '(' argument_list? ')' AsInvocationExpression«»
    // From: element_access and pointer_element_access (unsafe code support)
        | primary_expression '[' argument_list ']' AsElementAccess«» ElementAccessSemanticCheck«»
    // From: null_conditional_element_access
        | primary_expression '?' '[' argument_list ']' (null_forgiving_operator? dependent_access)* AsNullConditionalElementAccess«» ElementAccessSemanticCheck«»
    | this_access
    | base_access
    // From: post_increment_expression
        | primary_expression '++' AsPostIncrementExpression«»
    // From: post_decrement_expression
        | primary_expression '--' AsPostDecrementExpression«»
    // | null_forgiving_expression
        | primary_expression null_forgiving_operator AsNullForgivingExpression«»
    | array_creation_expression
    | object_creation_expression
    | delegate_creation_expression
    | anonymous_object_creation_expression
    | typeof_expression
    | sizeof_expression
    | checked_expression
    | unchecked_expression
    | default_value_expression
    | nameof_expression
    | anonymous_method_expression
    // From: pointer_member_access     // unsafe code support
        | primary_expression '->' identifier type_argument_list? AsPointerMemberAccess«»
    // From: pointer_element_access    // unsafe code support
        // covered by element_access replacement above
    | stackalloc_expression
    ;
```

> ---
> *Note:* While this change removes MLR and so makes the grammar functional it does not address other “issues” with the rule. For example *nameof_expression* and *pointer_element_access* (which is elided by the above change) alternatives are unreachable as they are subsumed by the *invocation_expression* and *element_access*
alternatives which precede them.

> Whether these “issues” are problems is subjective, a compiler can easily resolve them and the rules exist largely for expository purposes in the Standard.

> ---

---

## Interpolated Strings

The lexical rules for interpolated strings are context-sensitive and are not ANLTR-ready
in the Standard as how such rules are handled is an implementation detail, e.g. using
ANTLR modes.

Replacements and additions for interpolated strings are in “InterpolatedSupport.md”.
