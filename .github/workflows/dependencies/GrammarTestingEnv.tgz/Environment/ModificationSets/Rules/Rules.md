<!-- markdownlint-disable MD001 -->
<!-- Reason: This file copies headers & grammar from the Standard which means the
     headers may not obey MD001 – only increment by one header level at a time
-->
# Rules

This file contains grammar modifications to support some of the non-grammar rules of C#,
and some its quirks. Without these modifications while a C# sample might parse it may not
parse as expected.

## Right Shifts

The rules *right_shift* and *right_shift_assignment* require that the component tokens
are adjacent. This change adds a `NextTwoAdjacentPredicate«»` predicate to enforce this.

### 7.4.6 Operators and punctuators

```ANTLR
// [ADD] Adjacency Check
# Modify
right_shift
    : NextTwoAdjacentPredicate«» '>' '>'
    ;

// [ADD] Adjacency Check
# Modify
right_shift_assignment
    : NextTwoAdjacentPredicate«» '>' '>='
    ;
```

---

## When Antlr’s predication/priority goes wrong?

There are two (known!) cases where Antlr does the wrong thing in some cases.

First in *primary_no_array_creation_expression* the rule *parenthesized_expression* is listed immediately before (the recently introduced) *tuple_literal*. This can cause Antlr to try
to parse the latter as the former and barf when it finds the comma. Switching the order of the
two fixes the issue. This switch is incorporated into the MLR fix, and lost in it!

Second in *relational_expression* the introduction of the new form of `is` with a RHS of *pattern* causes a similar issue as it was added *after* the existing `is` taking a *type*.
The sequence of lexical tokens for of *type* is a subset of *pattern*, and Antlr tries to parse the latter as
former and barfs.

Unlike the first case exchanging the order of the two rules does not fix the issue.
The *constant_pattern* alternative of *pattern*, which expands via *constant_expression*
to *expression*, will match a type as a *simple_name* rather than as a *namespace_or_type_name*.
While not an issue for a compiler to sort out *per se*, once semantic information on the types
of identifiers is known, it messes with the disambiguation of *type_argument_list*.

The simple (YMMV 😉) solution is to:

- remove the “`relational_expression 'is' type`” alternative from *relational_expression*,
- add *type* as an option to *pattern* after *declaration_pattern* (this ordering is
important for the same reason as the *type_expression*/*parenthesized_expression* one is),
- predicate (`TypePatternPredicate«»`) the introduced option to only be active on the RHS
of an `is` (as *type* is not an alternative to *pattern* elsewhere), and
- finally post-recognition modify (action `ReplacePatternWithType«»`) the
*relational_expression* -> *pattern* -> *type* result eliding the *pattern* intermediate
node to the result matches the parse tree the grammar implies (this is a parallel to insertion of nodes elided to remove MLR).

### 11.2.1 General

```ANTLR
# Modify
pattern
    : declaration_pattern
    | TypePatternPredicate«» type ReplacePatternWithType«»
    | constant_pattern
    | var_pattern
    | positional_pattern
    | property_pattern
    | discard_pattern
    ;
```

### 12.12.1 General

```ANTLR
# Modify
relational_expression
    : shift_expression
    | relational_expression '<' shift_expression
    | relational_expression '>' shift_expression
    | relational_expression '<=' shift_expression
    | relational_expression '>=' shift_expression
    | relational_expression 'is' pattern
    | relational_expression 'as' type
    ;
```

Important: This fixing of `is` is important for disambiguating *type_argument_list*, the below.

---

## Recognition of `dynamic`

These two reorderings mean that `dynamic` will be recognised as the dynamic type
rather than as a user-defined type name. In a real implementation semantic checking would
of course distinguish them, here we are just tweaking the grammar for aesthetic reasons 🙂

### 8.2.1 General

```ANTLR
# Expect
non_nullable_reference_type
    : class_type
    | interface_type
    | array_type
    | delegate_type
    | 'dynamic'
    ;
# ReplaceWith
non_nullable_reference_type
    : 'dynamic'
    | class_type
    | interface_type
    | array_type
    | delegate_type
    ;
```

```ANTLR
# Expect
non_array_non_nullable_type
    : non_nullable_value_type
    | class_type
    | interface_type
    | delegate_type
    | 'dynamic'
    | type_parameter
    ;
# ReplaceWith
non_array_non_nullable_type
    : 'dynamic'
    | non_nullable_value_type
    | class_type
    | interface_type
    | delegate_type
    | type_parameter
    ;
```

---

## Type argument lists

As detailed in §6.2.5 *Grammar ambiguities* there are a number of places in the grammar
where there is an ambiguity between recognising a sequence of tokens as either a
*type_argument_list* or some kind of expression. The following algorithm is defined to resolve these:

> If a sequence of tokens can be parsed (in context) as a *simple_name* ([§12.8.4](expressions.md#1284-simple-names)), *member_access* ([§12.8.7](expressions.md#1287-member-access)), or *pointer_member_access* ([§23.6.3](unsafe-code.md#2363-pointer-member-access)) ending with a *type_argument_list* ([§8.4.2](types.md#842-type-arguments)), the token immediately following the closing `>` token is examined, to see if it is
>
> - One of `(  )  ]  }  :  ;  ,  .  ?  ==  !=  |  ^  &&  ||  &  [`; or
> - One of the relational operators `<  <=  >=  is as`; or
> - A contextual query keyword appearing inside a query expression; or
> - In certain contexts, *identifier* is treated as a disambiguating token. Those contexts are where the sequence of tokens being disambiguated is immediately preceded by one of the keywords `is`, `case` or `out`, or arises while parsing the first element of a tuple literal (in which case the tokens are preceded by `(` or `:` and the identifier is followed by a `,`) or a subsequent element of a tuple literal.
>
> If the following token is among this list, or an identifier in such a context, then the *type_argument_list* is retained as part of the *simple_name*, *member_access* or  *pointer_member-access* and any other possible parse of the sequence of tokens is discarded. Otherwise, the *type_argument_list* is not considered to be part of the *simple_name*, *member_access* or *pointer_member_access*, even if there is no other possible parse of the sequence of tokens.

The following change adds a `TypeArgumentListValidPredicate«»` predicate to implement this.

Note:

> This clause is both:
>
> - out-of-date – in terms of the list of clauses which require disambiguation,
> and those that do not;
> - and in what rules are required – possibly due to unintentional inclusion of
> implementation-specific details (there can be a difference between rules the C# grammar
> requires for correctness of the grammar and those a compiler might implement as a
> consequence of its particular parsing strategy to achieve the same outcome).
>
> These will be addressed in a forthcoming PR, however the Standard and the modifications
> here **will** need to be re-visited in C# 9 due to forthcoming pattern changes.

### 8.4.2 Type arguments

```ANTLR
# Modify
type_argument_list
    : TypeArgumentListValidPredicate«» '<' type_argument (',' type_argument)* '>'
    ;
```

---

## Variable references

A *variable_reference* is just an *expression* with the semantic requirement that the
expression is classified as a variable aka. returns a variable reference.

This action reports if a subset of the semantic restrictions on variable_reference are violated.

While no type information is available we know that many expressions cannot return a variable reference; e.g. most built in operators (+, >, et al.) and literals (numeric, string).

## 9.5 Variable references

```ANTLR
# Modify
variable_reference
    : expression VariableReferenceSemanticCheck«»
    ;
```

---

## Null-forgiving expressions

The null-forgiving expression has the semantic rule [§12.8.9.1]:

> It is a compile-time error to apply the null-forgiving operator more than once to the same expression, intervening parentheses notwithstanding.

We implement this with a simple check after a *null_forgiving_operator*
has been recognised and issue a semantic error message.

We *should* do it only for *null_forgiving_expression*, however that rule is altered by
MLR removal and we avoid layering changes when possible. Placing the check on
*null_forgiving_operator* will call it more often and redundantly – but the code
checks that the parent node of the *null_forgiving_operator* is a *null_forgiving_expression*,
or that it is called directly on the latter.

Due to the MLR removal and post parse reintroduction of nodes for inlined rules the code
also handles finding a *primary_no_array_creation_expression* standing in for
*null_forgiving_expression* should it be invoke prior to MLR fixup. MLR the gift that
keeps on giving! ;-(

#### 12.8.9.1 General

```ANTLR
// [ADD] Semantic check
# Modify
null_forgiving_operator
    : '!' NullForgivingSemanticCheck«»
    ;
```

---

## 2-way: Deconstruction assignment

There is a distinction between *deconstructor*s which appear at the start of a statement (so the derivation is *statement_expression* ➜ *assignment* ➜ *deconstructing_assignment*) and those elsewhere:

- Those at the start of a statement can contain *declaration_expression*s, and if they do so they cannot contain *variable_reference*s – the latter restriction is removed in C#10.
- Those elsewhere cannot contain *declaration_expression*s.

> Note: in the 3-way split into *tuple_literal*, *deconstructing_assignment* and *local_deconstructing_declaration* these restrictions are enforced by the grammar.

## 12.23.3 Deconstructing assignment

```ANTLR
# Modify
deconstructing_assignment
    : deconstructor '=' expression DeconstructingAssignmentCheck«»
    ;
```

## 3-way: Deconstruction declarations

From C#10 a *declaration_deconstructor* may include *variable_reference*(s), which means *deconstructor* becomes a subset of *declaration_deconstructor*, which in turn means the first deconstructor in a statement can be recognised as a declaration rather than as an assignment. The simple semantic rule to avoid this is requiring a *declaration_deconstructor* to contain at least one *declaration_expression*. This adds an action to *statement* to check ahead that the deconstructor contains a declaration.
+There is a distinction between *deconstructor*s which appear at the start of a statement (so the derivation is *statement_expression* ➜ *assignment* ➜ *deconstructing_assignment*) and those elsewhere:

Note: it might seem more logical for this check to be done in *declaration_statement* to disable just the *local_deconstructing_declaration* alternative. However that is too late for Antlr’s lookahead. So the action is on *statement* and only disables *declaration_statement* if it is destructor without a declaration, and so allow the other alternatives of *declaration_statement* to be considered by Antlr.

## 13.1 General

> ```DISABLED[ANTLR]
> # Modify
> statement
>     : labeled_statement
>     | AllowDeconstructingDeclarationPredicate«» declaration_statement
>     | embedded_statement
>     ;
> ```
