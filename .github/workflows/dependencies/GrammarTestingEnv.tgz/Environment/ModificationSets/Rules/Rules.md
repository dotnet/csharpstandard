<!-- markdownlint-disable MD001 -->
<!-- Reason: This file copies headers & grammar from the Standard which means the
     headers may not obey MD001 – only increment by one header level at a time
-->
# Rules

This file contains grammar modifications to support some of the non-grammar rules of C#,
and some its quirks. Without these modifications while a C# sample might parse it may not
parse as expected.

## Right Shifts

The rules *right_shift* and *right_shift_assignment* require that the component tokens
are adjacent. This change adds a `NextTwoAdjacentPredicate«»` predicate to enforce this.

### 7.4.6 Operators and punctuators

```ANTLR
// [ADD] Adjacency Check
# Modify
right_shift
    : NextTwoAdjacentPredicate«» '>' '>'
    ;

// [ADD] Adjacency Check
# Modify
right_shift_assignment
    : NextTwoAdjacentPredicate«» '>' '>='
    ;
```

---

## 12.17 Declaration expressions

To quote:

> A declaration expression shall only occur in the following syntactic contexts:
>
> - As an `out` *argument_value* in an *argument_list*.
> - As a simple discard `_` comprising the left side of a simple assignment ([§12.21.2](expressions.md#12212-simple-assignment)).
> - As a *tuple_element* in one or more recursively nested *tuple_expression*s, the outermost of which comprises the left side of a deconstructing assignment. A *deconstruction_expression* gives rise to declaration expressions in this position, even though the declaration expressions are not syntactically present.

Oh joy!

## 12.22 Expression

```ANTLR
# Modify
non_assignment_expression
    : DeclarationExpressionPredicate«» declaration_expression
    | conditional_expression
    | lambda_expression
    | query_expression
    ;
```

---

## When Antlr’s predication/priority goes wrong?

There are two (known!) cases where Antlr does the wrong thing in some cases.

First in *primary_no_array_creation_expression* the rule *parenthesized_expression* is listed immediately before (the recently introduced) *tuple_expression*. This can cause Antlr to try
to parse the latter as the former and barf when it finds the comma. Switching the order of the
two fixes the issue. This switch is incorporated into the MLR fix, and lost in it!

Second in *relational_expression* the introduction of the new form of `is` with a RHS of *pattern* causes a similar issue as it was added *after* the existing `is` taking a *type*.
The sequence of lexical tokens for of *type* is a subset of *pattern*, and Antlr tries to parse the latter as
former and barfs.

Unlike the first case exchanging the order of the two rules does not fix the issue.
The *constant_pattern* alternative of *pattern*, which expands via *constant_expression*
to *expression*, will match a type as a *simple_name* rather than as a *namespace_or_type_name*.
While not an issue for a compiler to sort out *per se*, once semantic information on the types
of identifiers is known, it messes with the disambiguation of *type_argument_list*.

The simple (YMMV 😉) solution is to:

- remove the “`relational_expression 'is' type`” alternative from *relational_expression*,
- add *type* as an option to *pattern* after *declaration_pattern* (this ordering is
important for the same reason as the *type_expression*/*parenthesized_expression* one is),
- predicate (`TypePatternPredicate«»`) the introduced option to only be active on the RHS
of an `is` (as *type* is not an alternative to *pattern* elsewhere), and
- finally post-recognition modify (action `ReplacePatternWithType«»`) the
*relational_expression* -> *pattern* -> *type* result eliding the *pattern* intermediate
node to the result matches the parse tree the grammar implies (this is a parallel to insertion of nodes elided to remove MLR).

### 11.2.1 General

```ANTLR
# Modify
pattern
    : declaration_pattern
    | TypePatternPredicate«» type ReplacePatternWithType«»
    | constant_pattern
    | var_pattern
    | positional_pattern
    | property_pattern
    | discard_pattern
    ;
```

### 12.12.1 General

```ANTLR
# Modify
relational_expression
    : shift_expression
    | relational_expression '<' shift_expression
    | relational_expression '>' shift_expression
    | relational_expression '<=' shift_expression
    | relational_expression '>=' shift_expression
    | relational_expression 'is' pattern
    | relational_expression 'as' type
    ;
```

Important: This fixing of `is` is important for disambiguating *type_argument_list*, the below.

---

## Type argument lists

As detailed in §6.2.5 *Grammar ambiguities* there are a number of places in the grammar
where there is an ambiguity between recognising a sequence of tokens as either a
*type_argument_list* or some kind of expression. The following algorithm is defined to resolve these:

> If a sequence of tokens can be parsed (in context) as a *simple_name* ([§12.8.4](expressions.md#1284-simple-names)), *member_access* ([§12.8.7](expressions.md#1287-member-access)), or *pointer_member_access* ([§23.6.3](unsafe-code.md#2363-pointer-member-access)) ending with a *type_argument_list* ([§8.4.2](types.md#842-type-arguments)), the token immediately following the closing `>` token is examined, to see if it is
>
> - One of `(  )  ]  }  :  ;  ,  .  ?  ==  !=  |  ^  &&  ||  &  [`; or
> - One of the relational operators `<  <=  >=  is as`; or
> - A contextual query keyword appearing inside a query expression; or
> - In certain contexts, *identifier* is treated as a disambiguating token. Those contexts are where the sequence of tokens being disambiguated is immediately preceded by one of the keywords `is`, `case` or `out`, or arises while parsing the first element of a tuple literal (in which case the tokens are preceded by `(` or `:` and the identifier is followed by a `,`) or a subsequent element of a tuple literal.
>
> If the following token is among this list, or an identifier in such a context, then the *type_argument_list* is retained as part of the *simple_name*, *member_access* or  *pointer_member-access* and any other possible parse of the sequence of tokens is discarded. Otherwise, the *type_argument_list* is not considered to be part of the *simple_name*, *member_access* or *pointer_member_access*, even if there is no other possible parse of the sequence of tokens.

The following change adds a `TypeArgumentListValidPredicate«»` predicate to implement this.

Note:

> This clause is both:
>
> - out-of-date – in terms of the list of clauses which require disambiguation,
> and those that do not;
> - and in what rules are required – possibly due to unintentional inclusion of
> implementation-specific details (there can be a difference between rules the C# grammar
> requires for correctness of the grammar and those a compiler might implement as a
> consequence of its particular parsing strategy to achieve the same outcome).
>
> These will be addressed in a forthcoming PR, however the Standard and the modifications
> here **will** need to be re-visited in C# 9 due to forthcoming pattern changes.

### 8.4.2 Type arguments

```ANTLR
# Modify
type_argument_list
    : TypeArgumentListValidPredicate«» '<' type_argument (',' type_argument)* '>'
    ;
```

---

## Null-forgiving expressions

The null-forgiving expression has the semantic rule [§12.8.9.1]:

> It is a compile-time error to apply the null-forgiving operator more than once to the same expression, intervening parentheses notwithstanding.

We implement this with a simple check after a *null_forgiving_operator*
has been recognised and issue a semantic error message.

We *should* do it only for *null_forgiving_expression*, however that rule is altered by
MLR removal and we avoid layering changes when possible. Placing the check on
*null_forgiving_operator* will call it more often and redundantly – but the code
checks that the parent node of the *null_forgiving_operator* is a *null_forgiving_expression*,
or that it is called directly on the latter.

Due to the MLR removal and post parse reintroduction of nodes for inlined rules the code
also handles finding a *primary_no_array_creation_expression* standing in for
*null_forgiving_expression* should it be invoke prior to MLR fixup. MLR the gift that
keeps on giving! ;-(

#### 12.8.9.1 General

```ANTLR
// [ADD] Semantic check
# Modify
null_forgiving_operator
    : '!' NullForgivingSemanticCheck«»
    ;
```
