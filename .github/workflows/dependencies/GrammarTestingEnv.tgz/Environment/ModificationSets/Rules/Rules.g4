parser grammar Rules_Support;

/* Important:
 *
 * This is just sample support code, it is not intended for inclusion in the
 * Standard or for distribution beyond TG2.
 *
 * The code works, no effort has gone into making it good, pretty or elegant!
 *
 * private is used to mark declarations not meant to be used outside this file
 *
 */

@parser::members
{
   // This predicate checks whether the next two tokens are adjacent in the source.
   // It is currently used for the right_shift and right_shift_assignment rules.

   boolean nextTwoAdjacent()
   {
      Token one = _input.LT(1);
      Token two = _input.LT(2);

      return one.getLine() == two.getLine()
             && (one.getCharPositionInLine() + one.getText().length()) == two.getCharPositionInLine();
   }

//======================================================================================

   // This predicate implements the disambiguation algorithm from §6.2.5

   private boolean validParentForDisambiguation(ParserRuleContext currentctx)
   {
      if (currentctx == null)
         return true;   // should not occur, we randomly pick to disambiguate

      ParserRuleContext parent = currentctx.getParent();

      if (parent == null)
         return false;  // should not occur, we randomly pick not to disambiguate

      int parentIndex = parent.getRuleIndex();

      if (parentIndex == RULE_primary_expression)
      {
         // MLR, the gift that keeps on giving :-(
         // rather than have the right nodes
         // fortunately the only nodes inlined which contain type_argument_list are:
         //    member_access, null_conditional_member_access and pointer_member_access
         // and they all need to be disambiguated

         return true;
      }

      switch (parentIndex)
      {
         case RULE_simple_name:
         case RULE_member_access:
         case RULE_base_access:
         case RULE_null_conditional_member_access:
         case RULE_dependent_access:
         case RULE_pointer_member_access:
            return true;
         default:
            return false;
      }
   }

   private boolean isIdentifier(int tokenType)
   {
      switch(tokenType)
      {
         case Simple_Identifier:

         // Contextual keywords – all are identifiers matching the identifier rule
         case KW_ADD:
         case KW_ALIAS:
         case KW_ASCENDING:
         case KW_ASYNC:
         case KW_AWAIT:
         case KW_BY:
         case KW_DESCENDING:
         case KW_DYNAMIC:
         case KW_EQUALS:
         case KW_FROM:
         case KW_GET:
         case KW_GLOBAL:
         case KW_GROUP:
         case KW_INTO:
         case KW_JOIN:
         case KW_LET:
         case KW_NAMEOF:
         case KW_NOTNULL:
         case KW_ON:
         case KW_ORDERBY:
         case KW_PARTIAL:
         case KW_REMOVE:
         case KW_SELECT:
         case KW_SET:
         case KW_UNMANAGED:
         case KW_VALUE:
         case KW_VAR:
         case KW_WHEN:
         case KW_WHERE:
         case KW_YIELD:
            return true;
         default:
            return false;
      }
   }

   private boolean inQueryClause(ParserRuleContext currentctx)
   {
      ParserRuleContext cursor = currentctx;
      while (cursor != null)
      {
         int ruleIndex = cursor.getRuleIndex();

         switch(ruleIndex)
         {
            case RULE_from_clause:
            case RULE_let_clause:
            case RULE_where_clause:
            case RULE_join_clause:
            case RULE_join_into_clause:
            case RULE_orderby_clause:
            case RULE_group_clause:
            case RULE_select_clause:
               return true;
         }

         // still here, move to parent
         cursor = cursor.getParent();
      }

      // no valid clause found, not in a query
      return false;
   }

   private boolean isQueryContextualKeyword(int tokenType)
   {
      switch(tokenType)
      {
         case KW_ASCENDING:
         case KW_BY:
         case KW_DESCENDING:
         case KW_EQUALS:
         case KW_FROM:
         case KW_GROUP:
         case KW_INTO:
         case KW_JOIN:
         case KW_LET:
         case KW_ON:
         case KW_ORDERBY:
         case KW_SELECT:
         case KW_WHERE:
            return true;
         default:
            return false;
      }
   }


   // The predicate, quotes from the text are in /* */ comments

   boolean typeArgumentListValid(ParserRuleContext currentctx)
   {
      // Note: LT may return null but never when arg > 0, so no need to check in such cases

      Token token = _input.LT(1);

      if (token.getType() != TK_LT)
      {
         // No TAL to disambiguate
         return false;
      }

      if (!validParentForDisambiguation(currentctx))
         return true; // let the predicate pass, no need to disambiguate

      int level = 1;
      int ix = 2;

      while(level != 0)
      {
         token = _input.LT(ix++);

         switch(token.getType())
         {
            case TK_LT: level++; break;
            case TK_GT: level--; break;
            case Token.EOF:
               return false;              // ran out of tokens, cannot be a TAL
            default:  ;
         }
      }

      token = _input.LT(ix);
      int tokenType = token.getType();

      switch(tokenType)
      {
         /* • One of (  )  ]  }  :  ;  ,  .  ?  ==  !=  |  ^  &&  ||  &  [
          */
         case TK_LPAREN:
         case TK_RPAREN:
         case TK_RBRACK:
         case TK_RBRACE:
         case TK_COLON:
         case TK_SEMI:
         case TK_COMMA:
         case TK_DOT:
         case TK_QMARK:
         case TK_EQ_EQ:
         case TK_NOT_EQ:
         case TK_OR:
         case TK_XOR:
         case TK_AND_AND:
         case TK_OR_OR:
         case TK_AND:
         case TK_LBRACK:
         /* • One of the relational operators <  <=  >=  is as
          */
         case TK_LT:
         case TK_LT_EQ:
         case TK_GT_EQ:
         case KW_IS:
         case KW_AS:
            return true;

         case Token.EOF:
            // trying to parse a possible TAL just before EOF,
            // at a guess saying it is a TAL might be less confusing
            return true;

         default:
            break;
      }

      /* • A contextual query keyword appearing inside a query expression
       */

      if ( isQueryContextualKeyword(tokenType) )
      {
         // Note: some of the contextual keywords can only appear in query expressions
         // and so the following test is redundant for them. However here we are after
         // simplicity not efficiency so we check for all of them

         if ( inQueryClause(currentctx) )
            return true;
      }

      return false;
   }

//======================================================================================

   // This predicate is part of the fixup for `is` now being `is *type*` or `is *pattern*`
   // The grammar rewrite “pushes”  the *type* into *pattern* as the second alternative,
   // and this predicate then enables that alternative iff the currentctx is a child of
   // and `is` *relation_expression*

   boolean typePatternPredicate(ParserRuleContext currentctx)
   {
      if (currentctx == null)
         return true;   // should not occur, we randomly pick to disambiguate

      ParserRuleContext parent = currentctx.getParent();

      if (parent == null)
         return false;  // should not occur, we randomly pick not to disambiguate

      int parentIndex = parent.getRuleIndex();

      if (parentIndex == RULE_relational_expression
          && parent.getChildCount() == 3
         )
      {
         ParseTree middleChild = parent.getChild(1);
         if (middleChild instanceof TerminalNodeImpl)
         {
            int tokenType = ((TerminalNodeImpl)middleChild).getSymbol().getType();
            if (tokenType == KW_IS)
            {
               return true;
            }
         }
      }

      // no valid context found, declaration_expression not allowed
      return false;
   }

   // This action is part of the fixup for `is`, a *type* has been recognised as a
   // *pattern* on the RHS of *relational_expression* `is` and we need to remove the
   // *pattern* node to match the original grammar

   void replacePatternWithType(ParserRuleContext currentctx)
   {
      ParserRuleContext parent = currentctx.getParent();

      ParseTree child = currentctx.getChild(0);

      child.setParent(parent);
      parent.children.set(2, child);
   }

//======================================================================================

   // This predicate reduces the places declaration_expression can occur following §12.17.
   // The semantic restrictions are based on both left & right context, as an Antlr
   // predicate is called before what follows it is parsed there is no right context
   // available to test. This places restrictions on what can be checked, e.g:
   //
   // • For deconstruction tuples on the LHS of a simple assignment this means that we
   //   cannot easily test for the assignment_operator as it is yet to be parsed.
   // • We cannot test that the derivation from tuple_element to declaration_expression
   //   is a single parent/child line.
   //
   // So this is a “liberal” predicate. While too much passes it does restrict enough so
   // that a tuple of the RHS is not erroneously parsed to include a (misplaced)
   // declaration_expression when instead another valid parse. For an example see the
   // test sample.
   //
   // Checks could be added after a successful parse to report semantic errors. The
   // grammar could also be re-written to enforce more of the restrictions. Such things
   // are left for possible future investigation.

   boolean declarationExpressionPredicate(ParserRuleContext currentctx)
   {
      // currentctx will be a non_assignment_expression if a declaration_expression is being
      // considered and we first need an ancestor chain back to either a tuple_element (for
      // deconstruction tuples) or a variable_reference (for out arguments) for a
      // declaration_expression to be possibly valid. In each case further checks are then
      // performed for deconstruction tuple on LHS of an assignment, and for out arguments.

      ParserRuleContext cursor = currentctx;
      while (cursor != null)
      {
         int ruleIndex = cursor.getRuleIndex();

         switch(ruleIndex)
         {
            case RULE_tuple_element:
               return declarationExpression_CheckForDeconstructingAssignment(cursor);

            case RULE_variable_reference:
               return declarationExpression_CheckForOutArgument(cursor);

            default:
               // move to parent
               cursor = cursor.getParent();
         }
      }

      // no valid context found, declaration_expression not permitted
      return false;
   }

   boolean declarationExpression_CheckForDeconstructingAssignment(ParserRuleContext cursor)
   {
      // cursor is at a tuple_element, check parent is a tuple_expression

      cursor = cursor.getParent();

      if (cursor == null || cursor.getRuleIndex() != RULE_tuple_expression)
         return false;

      // cursor is at a tuple_expression, traverse ancestor chain back to a tuple_element,
      // to allow for nested tuples, or to a unary_expression on the LHS of an assignment

      while (cursor != null)
      {
         int ruleIndex = cursor.getRuleIndex();

         switch(ruleIndex)
         {
            case RULE_tuple_element:
               // nested tuples, recurse
               return declarationExpression_CheckForDeconstructingAssignment(cursor);

            case RULE_unary_expression:
               // check on LHS of assignment
               ParserRuleContext parent = cursor.getParent();
               if (parent == null)
                  return false;
               else if(parent.getRuleIndex() == RULE_assignment)
                  return parent.getChild(0) == cursor; // check on LHS

               // fall through
            default:
               // move to parent
               cursor = cursor.getParent();
         }

      }

      // no valid context found, declaration_expression not permitted
      return false;

   }

   boolean declarationExpression_CheckForOutArgument(ParserRuleContext cursor)
   {
      // cursor is at a variable_reference, check parent is an argument_value

      cursor = cursor.getParent();
      if (cursor == null || cursor.getRuleIndex() != RULE_argument_value)
         return false;

      // now check the argument_value has two children and the first is `out`

      int children = cursor.getChildCount();
      if (children != 2)
         return false;  // can't be an “out argument_value”

      ParseTree child = cursor.getChild(0);
      if ( !(child instanceof TerminalNode) )
         return false;  // should not happen

      Token token = ((TerminalNode)child).getSymbol();

      return token.getType() == KW_OUT;
   }

//======================================================================================

   // This action reports the semantic restriction of applying ! to ! in §12.8.9.1

   void nullForgivingSemanticCheck(ParserRuleContext currentctx)
   {
      // first do a quick lexical scan backwards, if we find something other
      // than zero or more ')' preceeded by a '!' there cannot be semantic error
      // this loop will exit without prevToken underflowing or
      // exhausting LT as the expression before the current null-forgiving
      // operator has parsed correctly

      Token possibleNestedBang = null;
      for(int prevToken = -2; possibleNestedBang == null; prevToken--)
      {
         Token token = _input.LT(prevToken);

         switch (token.getType())
         {
            case TK_NOT:
               // possible semantic error: applying null-forgiving operator directly to result of another one
               possibleNestedBang = token; // break out of loop by saving the found bang
               break;

            case TK_RPAREN:
               // keep scanning backwards, using ()’s doesn’t invalidate rule
               break;

            default:
               // found token other than ! or ), no semantic error :-)
               return;
         }
      }

      // here we know we have `!` `)`* `!` but we don't know the first `!` is part of a
      // null_forgiving_expression, for example this meets the lexical check:
      //
      //    (s ?? r!)!
      //
      // but here the outer `!` is being applied to the result of `??`. So now we need
      // to traverse the parse tree and check that we find a null_forgiving_expression
      // as the operand of the outer `!`

      // first we find out where we need to start from as this check might be applied
      // to the null_forgiving_operator or null_forgiving_expression rules, and in the
      // latter case the node might still be a primary_no_array_creation_expression due
      // to MLR fixup – the gift that keeps on giving!

      ParserRuleContext startingNullForgivingExpr;

      int ruleIndex = currentctx.getRuleIndex();
      switch (ruleIndex)
      {
         case RULE_null_forgiving_operator:
            // attached to a null_forgiving_operator, check if child of null_forgiving_expression
            ParserRuleContext parent = currentctx.getParent();
            int parentIndex = parent.getRuleIndex();

            // the primary_expression is needed if MLR fixup hasn't occurred yet,
            // it may not be a pending null_forgiving_operator as the bang we started with could be
            // the first child but that will fall out as soon as we scan down  - yes a bit icky
            if ( ! (parentIndex == RULE_null_forgiving_expression
                    || (parentIndex == RULE_primary_expression
                        && parent.getChildCount() == 2
                       )
                   )
               )
            {
               return; // nothing to do, this is not a null_forgiving_expression
            }
            startingNullForgivingExpr = parent;
            break;
         case RULE_null_forgiving_expression:
            // attached to null_forgiving_expression
            startingNullForgivingExpr = currentctx;
            break;
         default:
            // attached to something else – error
            System.err.println(String.format("Action nullForgivingSemanticCheck attached to rule %s, ignored. Report to developer please.", ruleNames[ruleIndex]));
            return;
      }

      // we’re looking at the grammar rule:
      //
      //    null_forgiving_expression : primary_expression null_forgiving_operator;
      //
      // start with primary_expression, child 0, and work down skipping down any chains
      // (e.g. a -> b -> c) to real child (e.g. c), going through any parenthesized_expression
      // on the way. If we reach a null_forgiving_expression report semantic error.

      ParseTree cursorNode = startingNullForgivingExpr.getChild(0);

      while(true)
      {
         if (!(cursorNode instanceof ParserRuleContext))
         {
            return;  // didn't find a null_forgiving_expression
         }

         ParserRuleContext cursor = (ParserRuleContext)cursorNode;

         int cursorRuleIndex = cursor.getRuleIndex();
         switch (cursorRuleIndex)
         {
            case RULE_null_forgiving_expression:
               // semantic error, applying null-forgiving operator directly to result of another one

               Token currentToken = _input.LT(-1); // the current  `!`

               // cursor’s getStart() & getStop() might be the range of token for the
               // null_forgiving_expression containing possibleNestedBang, however
               // they are invariably null (set only during debug?). So we’ll just
               // use the location of possibleNestedBang

               int opLine = possibleNestedBang.getLine();
               int opChar = possibleNestedBang.getCharPositionInLine();
               notifySemanticError(currentToken.getLine(),
                                   currentToken.getCharPositionInLine(),
                                   String.format("null-forgiving `!` cannot be applied to the result of null-forgiving expression at (%d:%d)", opLine, opChar)
                                  );
               return;
            case RULE_parenthesized_expression:
               // just move on through - 3 children we need the middle one
               cursorNode = cursor.getChild(1);
               break;
            default:
               // some other node, if there is exactly one child move down, otherwise we’re done
               if (cursor.getChildCount() != 1)
               {
                  return;
               }

               cursorNode = cursor.getChild(0);
         }
      }
   }
}
