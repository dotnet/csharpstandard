parser grammar Rules_Support;

/* Important:
 *
 * This is just sample support code, it is not intended for inclusion in the
 * Standard or for distribution beyond TG2.
 *
 * The code works, no effort has gone into making it good, pretty or elegant!
 *
 * private is used to mark declarations not meant to be used outside this file
 *
 */

@parser::members
{
   // This predicate checks whether the next two tokens are adjacent in the source.
   // It is currently used for the right_shift and right_shift_assignment rules.

   boolean nextTwoAdjacent()
   {
      Token one = _input.LT(1);
      Token two = _input.LT(2);

      return one.getLine() == two.getLine()
             && (one.getCharPositionInLine() + one.getText().length()) == two.getCharPositionInLine();
   }

//======================================================================================

   // Some useful predicates

   private static boolean isIdentifier(int tokenType)
   {
      switch(tokenType)
      {
         case Simple_Identifier:

         // Contextual keywords – all are identifiers matching the identifier rule
         case KW_ADD:
         case KW_ALIAS:
         case KW_ASCENDING:
         case KW_ASYNC:
         case KW_AWAIT:
         case KW_BY:
         case KW_DESCENDING:
         case KW_DYNAMIC:
         case KW_EQUALS:
         case KW_FROM:
         case KW_GET:
         case KW_GLOBAL:
         case KW_GROUP:
         case KW_INTO:
         case KW_JOIN:
         case KW_LET:
         case KW_NAMEOF:
         case KW_NOTNULL:
         case KW_ON:
         case KW_ORDERBY:
         case KW_PARTIAL:
         case KW_REMOVE:
         case KW_SELECT:
         case KW_SET:
         case KW_UNMANAGED:
         case KW_VALUE:
         case KW_VAR:
         case KW_WHEN:
         case KW_WHERE:
         case KW_YIELD:

         // The discard token – not a contextual keyword per se
         case TK_DISCARD:
            return true;
         default:
            return false;
      }
   }

   private static boolean isStandardType(int tokenType)
   {
      switch(tokenType)
      {
         case Simple_Identifier:

         // Contextual keywords – all are identifiers matching the identifier rule
         case KW_BOOL:
         case KW_BYTE:
         case KW_CHAR:
         case KW_DECIMAL:
         case KW_DOUBLE:
         case KW_DYNAMIC:
         case KW_FLOAT:
         case KW_INT:
         case KW_LONG:
         case KW_OBJECT:
         case KW_SBYTE:
         case KW_SHORT:
         case KW_STRING:
         case KW_UINT:
         case KW_ULONG:
         case KW_USHORT:
         case KW_VAR:
            return true;
         default:
            return false;
      }
   }

   private static boolean isQueryContextualKeyword(int tokenType)
   {
      switch(tokenType)
      {
         case KW_ASCENDING:
         case KW_BY:
         case KW_DESCENDING:
         case KW_EQUALS:
         case KW_FROM:
         case KW_GROUP:
         case KW_INTO:
         case KW_JOIN:
         case KW_LET:
         case KW_ON:
         case KW_ORDERBY:
         case KW_SELECT:
         case KW_WHERE:
            return true;
         default:
            return false;
      }
   }

   // utilities

   // return the original source matched by a rule
   // aim is to improve on Antlr’s getText() which strips whitespace
   private static String ruleSource(ParserRuleContext context)
   {
      Token start = context.getStart();
      if (start == null)
      {
         // no start… just fall back to Antlr
         return context.getText();
      }

      Token stop = context.getStop();
      if (stop != null)
      {
         // got start & stop, use tokenRangeSource
         return tokenRangeSource(start, stop);
      }

      int childCount = context.getChildCount();
      if (childCount == 0)
      {
         // no children, start must be it
         return start.getText();
      }

      // work down the last child chain until we find the last token or fail
      ParseTree cursor = context;
      while (childCount != 0)
      {
         cursor = cursor.getChild(childCount-1);

         if (cursor instanceof TerminalNodeImpl)
         {
            stop = ((TerminalNodeImpl)cursor).getSymbol();
            return tokenRangeSource(start, stop);
         }
         else if (cursor instanceof ParserRuleContext)
         {
            stop = ((ParserRuleContext)cursor).getStop();
            if (stop != null)
            {
               // as we're going down last child chain as soon as we have a stop we’re good
               return tokenRangeSource(start, stop);
            }
         }

         // not found last token, update child count and loop to move down
         childCount = cursor.getChildCount();
      }

      // failed to do better, fall back to Antlr
      return context.getText();
   }

   // return the original source bounded by two tokens
   private static String tokenRangeSource(Token first, Token last)
   {
      // sanity checking, are both tokens from the same stream?
      CharStream stream = first.getInputStream();
      if (stream != last.getInputStream())
         return "Internal error, tokens from different streams. Please report.";

      int startIndex = first.getStartIndex();
      int stopIndex = last.getStopIndex();

      if (stopIndex < startIndex)
         return "Internal error, tokens out of order. Please report.";

      return stream.getText(new Interval(startIndex, stopIndex));
   }

//======================================================================================

   // This predicate implements the disambiguation algorithm from §6.2.5

   private static boolean validParentForDisambiguation(ParserRuleContext currentctx)
   {
      if (currentctx == null)
         return true;   // should not occur, we randomly pick to disambiguate

      ParserRuleContext parent = currentctx.getParent();

      if (parent == null)
         return false;  // should not occur, we randomly pick not to disambiguate

      int parentIndex = parent.getRuleIndex();

      if (parentIndex == RULE_primary_expression)
      {
         // MLR, the gift that keeps on giving :-(
         // rather than have the right nodes
         // fortunately the only nodes inlined which contain type_argument_list are:
         //    member_access, null_conditional_member_access and pointer_member_access
         // and they all need to be disambiguated

         return true;
      }

      switch (parentIndex)
      {
         case RULE_simple_name:
         case RULE_member_access:
         case RULE_base_access:
         case RULE_null_conditional_member_access:
         case RULE_dependent_access:
         case RULE_pointer_member_access:
            return true;
         default:
            return false;
      }
   }

   private boolean inQueryClause(ParserRuleContext currentctx)
   {
      ParserRuleContext cursor = currentctx;
      while (cursor != null)
      {
         int ruleIndex = cursor.getRuleIndex();

         switch(ruleIndex)
         {
            case RULE_from_clause:
            case RULE_let_clause:
            case RULE_where_clause:
            case RULE_join_clause:
            case RULE_join_into_clause:
            case RULE_orderby_clause:
            case RULE_group_clause:
            case RULE_select_clause:
               return true;
         }

         // still here, move to parent
         cursor = cursor.getParent();
      }

      // no valid clause found, not in a query
      return false;
   }

   // The predicate, quotes from the text are in /* */ comments

   boolean typeArgumentListValid(ParserRuleContext currentctx)
   {
      // Note: LT may return null but never when arg > 0, so no need to check in such cases

      Token token = _input.LT(1);

      if (token.getType() != TK_LT)
      {
         // No TAL to disambiguate
         return false;
      }

      if (!validParentForDisambiguation(currentctx))
         return true; // let the predicate pass, no need to disambiguate

      int level = 1;
      int ix = 2;

      while(level != 0)
      {
         token = _input.LT(ix++);

         switch(token.getType())
         {
            case TK_LT: level++; break;
            case TK_GT: level--; break;
            case Token.EOF:
               return false;              // ran out of tokens, cannot be a TAL
            default:  ;
         }
      }

      token = _input.LT(ix);
      int tokenType = token.getType();

      switch(tokenType)
      {
         /* • One of (  )  ]  }  :  ;  ,  .  ?  ==  !=  |  ^  &&  ||  &  [
          */
         case TK_LPAREN:
         case TK_RPAREN:
         case TK_RBRACK:
         case TK_RBRACE:
         case TK_COLON:
         case TK_SEMI:
         case TK_COMMA:
         case TK_DOT:
         case TK_QMARK:
         case TK_EQ_EQ:
         case TK_NOT_EQ:
         case TK_OR:
         case TK_XOR:
         case TK_AND_AND:
         case TK_OR_OR:
         case TK_AND:
         case TK_LBRACK:
         /* • One of the relational operators <  <=  >=  is as
          */
         case TK_LT:
         case TK_LT_EQ:
         case TK_GT_EQ:
         case KW_IS:
         case KW_AS:
            return true;

         case Token.EOF:
            // trying to parse a possible TAL just before EOF,
            // at a guess saying it is a TAL might be less confusing
            return true;

         default:
            break;
      }

      /* • A contextual query keyword appearing inside a query expression
       */

      if ( isQueryContextualKeyword(tokenType) )
      {
         // Note: some of the contextual keywords can only appear in query expressions
         // and so the following test is redundant for them. However here we are after
         // simplicity not efficiency so we check for all of them

         if ( inQueryClause(currentctx) )
            return true;
      }

      return false;
   }

//======================================================================================

   // This predicate is part of the fixup for `is` now being `is *type*` or `is *pattern*`
   // The grammar rewrite “pushes”  the *type* into *pattern* as the second alternative,
   // and this predicate then enables that alternative iff the currentctx is a child of
   // and `is` *relation_expression*

   boolean typePatternPredicate(ParserRuleContext currentctx)
   {
      if (currentctx == null)
         return true;   // should not occur, we randomly pick to disambiguate

      ParserRuleContext parent = currentctx.getParent();

      if (parent == null)
         return false;  // should not occur, we randomly pick not to disambiguate

      int parentIndex = parent.getRuleIndex();

      if (parentIndex == RULE_relational_expression
          && parent.getChildCount() == 3
         )
      {
         ParseTree middleChild = parent.getChild(1);
         if (middleChild instanceof TerminalNodeImpl)
         {
            int tokenType = ((TerminalNodeImpl)middleChild).getSymbol().getType();
            if (tokenType == KW_IS)
            {
               return true;
            }
         }
      }

      // no valid context found, declaration_expression not allowed
      return false;
   }

   // This action is part of the fixup for `is`, a *type* has been recognised as a
   // *pattern* on the RHS of *relational_expression* `is` and we need to remove the
   // *pattern* node to match the original grammar

   void replacePatternWithType(ParserRuleContext currentctx)
   {
      ParserRuleContext parent = currentctx.getParent();

      ParseTree child = currentctx.getChild(0);

      child.setParent(parent);
      parent.children.set(2, child);
   }

//======================================================================================

   // This action reports the semantic restriction of applying ! to ! in §12.8.9.1

   void nullForgivingSemanticCheck(ParserRuleContext currentctx)
   {
      // first do a quick lexical scan backwards, if we find something other
      // than zero or more ')' preceeded by a '!' there cannot be semantic error
      // this loop will exit without prevToken underflowing or
      // exhausting LT as the expression before the current null-forgiving
      // operator has parsed correctly

      Token possibleNestedBang = null;
      for(int prevToken = -2; possibleNestedBang == null; prevToken--)
      {
         Token token = _input.LT(prevToken);

         switch (token.getType())
         {
            case TK_NOT:
               // possible semantic error: applying null-forgiving operator directly to result of another one
               possibleNestedBang = token; // break out of loop by saving the found bang
               break;

            case TK_RPAREN:
               // keep scanning backwards, using ()’s doesn’t invalidate rule
               break;

            default:
               // found token other than ! or ), no semantic error :-)
               return;
         }
      }

      // here we know we have `!` `)`* `!` but we don't know the first `!` is part of a
      // null_forgiving_expression, for example this meets the lexical check:
      //
      //    (s ?? r!)!
      //
      // but here the outer `!` is being applied to the result of `??`. So now we need
      // to traverse the parse tree and check that we find a null_forgiving_expression
      // as the operand of the outer `!`

      // first we find out where we need to start from as this check might be applied
      // to the null_forgiving_operator or null_forgiving_expression rules, and in the
      // latter case the node might still be a primary_no_array_creation_expression due
      // to MLR fixup – the gift that keeps on giving!

      ParserRuleContext startingNullForgivingExpr;

      int ruleIndex = currentctx.getRuleIndex();
      switch (ruleIndex)
      {
         case RULE_null_forgiving_operator:
            // attached to a null_forgiving_operator, check if child of null_forgiving_expression
            ParserRuleContext parent = currentctx.getParent();
            int parentIndex = parent.getRuleIndex();

            // the primary_expression is needed if MLR fixup hasn't occurred yet,
            // it may not be a pending null_forgiving_operator as the bang we started with could be
            // the first child but that will fall out as soon as we scan down  - yes a bit icky
            if ( ! (parentIndex == RULE_null_forgiving_expression
                    || (parentIndex == RULE_primary_expression
                        && parent.getChildCount() == 2
                       )
                   )
               )
            {
               return; // nothing to do, this is not a null_forgiving_expression
            }
            startingNullForgivingExpr = parent;
            break;
         case RULE_null_forgiving_expression:
            // attached to null_forgiving_expression
            startingNullForgivingExpr = currentctx;
            break;
         default:
            // attached to something else – error
            System.err.println(String.format("Action nullForgivingSemanticCheck attached to rule %s, ignored. Report to developer please.", ruleNames[ruleIndex]));
            return;
      }

      // we’re looking at the grammar rule:
      //
      //    null_forgiving_expression : primary_expression null_forgiving_operator;
      //
      // start with primary_expression, child 0, and work down skipping down any chains
      // (e.g. a -> b -> c) to real child (e.g. c), going through any parenthesized_expression
      // on the way. If we reach a null_forgiving_expression report semantic error.

      ParseTree cursorNode = startingNullForgivingExpr.getChild(0);

      while(true)
      {
         if (!(cursorNode instanceof ParserRuleContext))
         {
            return;  // didn't find a null_forgiving_expression
         }

         ParserRuleContext cursor = (ParserRuleContext)cursorNode;

         int cursorRuleIndex = cursor.getRuleIndex();
         switch (cursorRuleIndex)
         {
            case RULE_null_forgiving_expression:
               // semantic error, applying null-forgiving operator directly to result of another one

               Token currentToken = _input.LT(-1); // the current  `!`

               // cursor’s getStart() & getStop() might be the range of token for the
               // null_forgiving_expression containing possibleNestedBang, however
               // they are invariably null (set only during debug?). So we’ll just
               // use the location of possibleNestedBang

               int opLine = possibleNestedBang.getLine();
               int opChar = possibleNestedBang.getCharPositionInLine();
               notifySemanticError(currentToken.getLine(),
                                   currentToken.getCharPositionInLine(),
                                   String.format("null-forgiving `!` cannot be applied to the result of null-forgiving expression at (%d:%d)", opLine, opChar)
                                  );
               return;
            case RULE_parenthesized_expression:
               // just move on through - 3 children we need the middle one
               cursorNode = cursor.getChild(1);
               break;
            default:
               // some other node, if there is exactly one child move down, otherwise we’re done
               if (cursor.getChildCount() != 1)
               {
                  return;
               }

               cursorNode = cursor.getChild(0);
         }
      }
   }

//======================================================================================

   // This action reports if a subset of the semantic restrictions
   // on variable_reference are violated.
   //
   // While no type information is available we know that many expressions cannot
   // return a variable reference; e.g. most built in operators (+, >, et al.) and literals
   // (numeric, string).
   //
   // The algorithm here simply skips intermediate nodes and then checks the found node
   // for the known cases to determine if the overall expression is either definitely
   // not a variable reference, or we don't know either way.
   //
   // This will, among other cases, report a semantic error in destructors to a sufficient
   // level that if the input has the form of a declaration expression it will be flagged
   // as an invalid variable reference.


   void variableReferenceSemanticCheck(ParserRuleContext currentctx)
   {
      ParserRuleContext startingVariableReference;

      int ruleIndex = currentctx.getRuleIndex();
      switch (ruleIndex)
      {
         case RULE_variable_reference:
            // at a variable_reference
            if (currentctx.getChildCount() == 1)
            {
               ParseTree child = currentctx.getChild(0);
               if (child instanceof ParserRuleContext)
               {
                  ParserRuleContext childContext = (ParserRuleContext)child;
                  int childRuleIndex = childContext.getRuleIndex();
                  if(childRuleIndex == RULE_expression)
                  {
                     // we’re looking at the grammar rule: variable_reference -> expression
                     // pass the expression to start the scan
                     if (scanForNonVariableReference(childContext))
                     {
                        Token start = currentctx.getStart();
                        System.err.println(String.format("(%d:%d) Semantic error, expression is not a variable reference: %s", start.getLine(), start.getCharPositionInLine(), ruleSource(currentctx)));

                     }
                     return;
                  }
                  else
                  {
                     System.err.println(String.format("Action variableReferenceSemanticCheck attached to rule %s -> %s «%s». Report to developer please.", ruleNames[ruleIndex], ruleNames[childRuleIndex], currentctx.getText()));
                     return;
                  }
               }
            }
            // variable_reference is not an expression – fall thru

         default:
            // attached to something else – error
            System.err.println(String.format("Action variableReferenceSemanticCheck attached to rule %s, ignored. Report to developer please.", ruleNames[ruleIndex]));
            return;
      }
   }

   boolean scanForNonVariableReference(ParserRuleContext start)
   {
      // scan down through intermediate nodes until we either hit a node we know is/isn’t
      // a variable reference, or a node > 1 child and examine those cases

      ParserRuleContext cursor = start;

      while(true)
      {
         int cursorRuleIndex = cursor.getRuleIndex();

         switch (cursorRuleIndex)
         {
            // rules which are never variable references (from primary_expression)
            case RULE_literal:
            case RULE_interpolated_string_expression:
            case RULE_tuple_literal:
            case RULE_post_increment_expression:
            case RULE_post_decrement_expression:
            case RULE_null_forgiving_expression:
            case RULE_array_creation_expression:
            case RULE_object_creation_expression:
            case RULE_delegate_creation_expression:
            case RULE_anonymous_object_creation_expression:
            case RULE_typeof_expression:
            case RULE_sizeof_expression:
            case RULE_checked_expression:
            case RULE_unchecked_expression:
            case RULE_default_value_expression:
            case RULE_nameof_expression:
            case RULE_anonymous_method_expression:
               return true; // found a non variable reference;

            // rules which are never variable references (from unary_expression)
            case RULE_pre_increment_expression:
            case RULE_pre_decrement_expression:
            case RULE_cast_expression:
            case RULE_await_expression:
               return true;

            default:
               // fall through
         }

         int childCount = cursor.getChildCount();

         if (childCount > 1)
         {
            // reached end of intermediate nodes
            switch (cursorRuleIndex)
            {
               // standard operators do not return variable references
               case RULE_conditional_or_expression:
               case RULE_conditional_and_expression:
               case RULE_inclusive_or_expression:
               case RULE_exclusive_or_expression:
               case RULE_and_expression:
               case RULE_equality_expression:
               case RULE_relational_expression:
               case RULE_shift_expression:
               case RULE_additive_expression:
               case RULE_multiplicative_expression:
               case RULE_switch_expression:
               case RULE_range_expression:
                  return true;

               case RULE_conditional_expression:
                  if (childCount == 5)
                  {
                     // null_coalescing_expression '?' expression ':' expression
                     return true;
                  }
                  else
                  {
                     // null_coalescing_expression '?' 'ref' variable_reference ':' 'ref' variable_reference
                     // definitely a variable reference
                     return false;
                  }

               case RULE_unary_expression:
                  // if a unary expression has 2 children it is a standard unary operator
                  // and does not return a variable reference
                  if (childCount == 2)
                     return true;

                  // otherwise move on down
                  break;

               default:
                  return false;
            }
         }

         if (childCount != 1)
         {
            // not an intermediate node so we cant advance (is this case possible here?)
            return false;
         }

         ParseTree nextNode = cursor.getChild(0);

         if (!(nextNode instanceof ParserRuleContext))
         {
            // presumably a Token, but is this possible here?
            return false;
         }

         // move on down
         cursor = (ParserRuleContext)nextNode;
      }
   }

//======================================================================================

   // This action reports if the semantic restrictions
   // on deconstructing_assignment are violated.

   void deconstructingAssignmentCheck(ParserRuleContext currentctx)
   {
      ParserRuleContext startingVariableReference;

      int ruleIndex = currentctx.getRuleIndex();
      switch (ruleIndex)
      {
         case RULE_deconstructing_assignment:
            // at a deconstructing_assignment
            if (currentctx.getChildCount() == 3)
            {
               ParseTree child = currentctx.getChild(0);
               if (child instanceof ParserRuleContext)
               {
                  ParserRuleContext childContext = (ParserRuleContext)child;
                  int childRuleIndex = childContext.getRuleIndex();
                  if(childRuleIndex == RULE_deconstructor)
                  {
//                      DeconstructorChecker checker = new DeconstructorChecker(currentctx, childContext);
//                      checker.analyse();
                     new DeconstructorChecker().analyse(currentctx, childContext);
                     return;
                  }
                  else
                  {
                     // attached to something else – error
                     System.err.println(String.format("Action deconstructingAssignmentCheck attached to rule %s -> %s «%s». Report to developer please.", ruleNames[ruleIndex], ruleNames[childRuleIndex], currentctx.getText()));
                     return;
                  }
               }
            }
            // fall thru

         default:
            // attached to something else – error
            System.err.println(String.format("Action deconstructingAssignmentCheck attached to rule %s, ignored. Report to developer please.", ruleNames[ruleIndex]));
            return;
      }
   }

   // class just used for grouping
   private static class DeconstructorChecker
   {
      // Need to apply different checks depending on whether the assignment is a statement
      // in a special place so this checks and returns a boolean.
      // Case 1: statement -> embedded_statement -> expression_statement -> statement_expression -> assignment -> deconstructing_assignment
      // Case 2: for_initializer -> statement_expression_list -> statement_expression -> assignment -> deconstructing_assignment
      private boolean checkStatementLevel(ParserRuleContext assignmentNode)
      {
         ParserRuleContext parent = assignmentNode.getParent();

         if (parent == null || parent.getRuleIndex() != RULE_assignment) return false;
         parent = parent.getParent(); // move to grandparent
         if (parent == null || parent.getRuleIndex() != RULE_statement_expression) return false;
         parent = parent.getParent(); // up the ancestor chain…
         if (parent == null) return false;
         switch(parent.getRuleIndex())
         {
            case RULE_expression_statement:
               parent = parent.getParent(); // up the ancestor chain…
               if (parent == null || parent.getRuleIndex() != RULE_embedded_statement) return false;
               parent = parent.getParent(); // up the ancestor chain…
               return parent != null && parent.getRuleIndex() == RULE_statement;

            case RULE_statement_expression_list:
               parent = parent.getParent(); // up the ancestor chain…
               return parent != null && parent.getRuleIndex() == RULE_for_initializer;
         }
         return false;
      }

      // Utility to get the nth child as a ParserRuleContext
      private ParserRuleContext getChildRule(ParserRuleContext rule, int child)
      {
            ParseTree childNode = rule.getChild(child);
            if (childNode == null)
            {
               // should not happen
               Token start = rule.getStart();
               System.err.println(String.format("(%d:%d) Missing child %d of %s, please report: %s", start.getLine(), start.getCharPositionInLine(), child, ruleNames[rule.getRuleIndex()], ruleSource(rule)));
               return null;
            }
            if (!(childNode instanceof ParserRuleContext))
            {
               // should not happen
               Token start = rule.getStart();
               System.err.println(String.format("(%d:%d) Unexpected child %d of %s, please report: %s", start.getLine(), start.getCharPositionInLine(), child, ruleNames[rule.getRuleIndex()], ruleSource(rule)));
               return null;
            }

            return (ParserRuleContext)childNode;
      }

      // Requirement: A general deconstructor (not statement level) must contain no declaration_expressions
      private void analyseGeneralDeconstructor(ParserRuleContext deconstructor)
      {
         // a deconstructor is of the form: ( child , child, …) or its an abridged_deconstructor
         // node children start at 0 (the opening paren) and for the former every odd
         // child is one we must check
         int totalChildCount = deconstructor.getChildCount();

         if (totalChildCount == 1) // abridged_deconstructor
         {
            // not allowed
            Token start = deconstructor.getStart();
            System.err.println(String.format("(%d:%d) Error, abridged_deconstructor not allowed here: %s", start.getLine(), start.getCharPositionInLine(), ruleSource(deconstructor)));
            return;
         }

         for (int cursor = 1; cursor < totalChildCount; cursor += 2)
         {
            // expecting deconstructor_element -> declaration_expression | deconstructor | discard_token | variable_reference
            // first check child is deconstructor_element
            ParserRuleContext cursorRule = getChildRule(deconstructor, cursor);
            int cursorRuleIndex = cursorRule.getRuleIndex();
            if (cursorRuleIndex != RULE_deconstructor_element || cursorRule.getChildCount() != 1)
            {
               // should not happen
               Token start = cursorRule.getStart();
               System.err.println(String.format("(%d:%d) Unexpected deconstructor member, please report: %s", start.getLine(), start.getCharPositionInLine(), cursor, ruleSource(cursorRule)));
               return;
            }

            // now get child of deconstructor_element
            cursorRule = getChildRule(cursorRule, 0);
            Token start = cursorRule.getStart();
            cursorRuleIndex = cursorRule.getRuleIndex();
            switch (cursorRuleIndex)
            {
               case RULE_discard_token:
               case RULE_variable_reference:
                  // both OK
                  continue;
               case RULE_deconstructor:
                  // nested deconstructor, recurse
                  analyseGeneralDeconstructor(cursorRule);
                  continue;
               case RULE_declaration_expression:
                  // not allowed
                  System.err.println(String.format("(%d:%d) Error, declaration_expression not allowed here: %s", start.getLine(), start.getCharPositionInLine(), ruleSource(cursorRule)));
                  continue;
               default:
                  // should not happen
                  System.err.println(String.format("(%d:%d) Unexpected deconstructor_element member, please report: %s", start.getLine(), start.getCharPositionInLine(), cursor, ruleSource(cursorRule)));
                  return; // don’t scan reset of deconstructor
            }
         }
      }

      // Requirement: If a statement level deconstructor has any declarations it cannot have any variable references
      // This function returns true if there is a declaration in the deconstructor
      private boolean scanDeconstructorForDeclarations(ParserRuleContext deconstructor)
      {
         // a deconstructor is of the form: ( child , child, …) or its an abridged_deconstructor
         // node children start at 0 (the opening paren) and for the former every odd
         // child is one we must check
         int totalChildCount = deconstructor.getChildCount();

         if (totalChildCount == 1) // abridged_deconstructor
         {
            return true;
         }

         for (int cursor = 1; cursor < totalChildCount; cursor += 2)
         {
            // expecting deconstructor_element -> declaration_expression | deconstructor | discard_token | variable_reference
            // first check child is deconstructor_element
            ParserRuleContext cursorRule = getChildRule(deconstructor, cursor);
            int cursorRuleIndex = cursorRule.getRuleIndex();
            if (cursorRuleIndex != RULE_deconstructor_element || cursorRule.getChildCount() != 1)
            {
               // should not happen
               Token start = cursorRule.getStart();
               System.err.println(String.format("(%d:%d) Unexpected deconstructor member, please report: %s", start.getLine(), start.getCharPositionInLine(), cursor, ruleSource(cursorRule)));
               return false;
            }

            // now get child of deconstructor_element
            cursorRule = getChildRule(cursorRule, 0);
            Token start = cursorRule.getStart();
            cursorRuleIndex = cursorRule.getRuleIndex();
            switch (cursorRuleIndex)
            {
               case RULE_discard_token:
               case RULE_variable_reference:
                  // both OK
                  continue;
               case RULE_deconstructor:
                  // nested deconstructor, recurse
                  if (scanDeconstructorForDeclarations(cursorRule)) return true;
                  continue;
               case RULE_declaration_expression:
                  return true;
               default:
                  // should not happen
                  System.err.println(String.format("(%d:%d) Unexpected deconstructor_element member, please report: %s", start.getLine(), start.getCharPositionInLine(), cursor, ruleSource(cursorRule)));
                  return false; // don’t scan reset of deconstructor
            }
         }
         return false; // did not find a declaration
      }

      private void reportVariableReferencesInDeconstructor(ParserRuleContext deconstructor)
      {
         // a deconstructor is of the form: ( child , child, …) or its an abridged_deconstructor
         // node children start at 0 (the opening paren) and for the former every odd
         // child is one we must check
         int totalChildCount = deconstructor.getChildCount();

         if (totalChildCount == 1) // abridged_deconstructor
         {
            return;
         }

         for (int cursor = 1; cursor < totalChildCount; cursor += 2)
         {
            // expecting deconstructor_element -> declaration_expression | deconstructor | discard_token | variable_reference
            // first check child is deconstructor_element
            ParserRuleContext cursorRule = getChildRule(deconstructor, cursor);
            int cursorRuleIndex = cursorRule.getRuleIndex();
            if (cursorRuleIndex != RULE_deconstructor_element || cursorRule.getChildCount() != 1)
            {
               // should not happen
               Token start = cursorRule.getStart();
               System.err.println(String.format("(%d:%d) Unexpected deconstructor member, please report: %s", start.getLine(), start.getCharPositionInLine(), cursor, ruleSource(cursorRule)));
               return;
            }

            // now get child of deconstructor_element
            cursorRule = getChildRule(cursorRule, 0);
            Token start = cursorRule.getStart();
            cursorRuleIndex = cursorRule.getRuleIndex();
            switch (cursorRuleIndex)
            {
               case RULE_discard_token:
               case RULE_declaration_expression:
                  // both OK
                  continue;
               case RULE_deconstructor:
                  // nested deconstructor, recurse
                  reportVariableReferencesInDeconstructor(cursorRule);
                  continue;
               case RULE_variable_reference:
                  // not allowed
                  System.err.println(String.format("(%d:%d) Error, variable_reference not allowed here: %s", start.getLine(), start.getCharPositionInLine(), ruleSource(cursorRule)));
                  continue;
               default:
                  // should not happen
                  System.err.println(String.format("(%d:%d) Unexpected deconstructor_element member, please report: %s", start.getLine(), start.getCharPositionInLine(), cursor, ruleSource(cursorRule)));
                  return; // don’t scan reset of deconstructor
            }
         }
      }

      public void analyse(ParserRuleContext assignmentNode, ParserRuleContext deconstructorNode)
      {
         if (!checkStatementLevel(assignmentNode))
            analyseGeneralDeconstructor(deconstructorNode);
         // the following check is removed for C#10
         else if (scanDeconstructorForDeclarations(deconstructorNode))
            reportVariableReferencesInDeconstructor(deconstructorNode);
      }
   }

//======================================================================================

   // This predicate checks if a local_deconstructing_declaration contains at least
   // one declaration_expression. As a selection predicate it is doing this before
   // the input is parsed but after tokenisation, so this is a lookahead token
   // based check, let the fun begin…

   private class Scanner
   {
      TokenStream input;
      public int cursor;
      public Token token;
      public int tokenType;

      public Scanner(TokenStream _input)
      {
         input = _input;
         cursor = 1;
         token = input.LT(1);
         tokenType = token.getType();
      }

      public Scanner advance()
      {
         token = input.LT(++cursor);
         tokenType = token.getType();
         return this;
      }

      public void reset(int offset)
      {
         cursor = offset;
         token = input.LT(cursor);
         tokenType = token.getType();
      }

      public Token peek(int offset) { return input.LT(cursor + offset); }

      public void printRange(String title, int start, int end)
      {
         Token first = input.LT(start);
         System.err.println(String.format("(%d:%d) %s: %s", first.getLine(), first.getCharPositionInLine(), title, tokenRangeSource(first, input.LT(end-1))));
      }
   }

   private boolean checkForAbridgedDeconstructor(Scanner scanner)
   {
      // check for "var (" – enough to recognise an abridged_deconstructor
      // does not advance cursor
      return scanner.tokenType == KW_VAR && scanner.peek(1).getType() == TK_LPAREN;
   }

   private boolean isCommaOrRParen(int tokenType)
   {
      return tokenType == TK_COMMA || tokenType == TK_RPAREN;
   }

   private boolean checkForSimpleDeclaration(Scanner scanner)
   {
      // check for "type identifier comma or rparen" – enough to recognise a simple declaration
      // does not advance cursor
      return isStandardType(scanner.tokenType)
             && isIdentifier(scanner.peek(1).getType())
             && isCommaOrRParen(scanner.peek(2).getType());
   }

   // consume a token kind, return boolean success
   private boolean consumeKind(Scanner scanner, int tokenType)
   {
      if ( scanner.tokenType != tokenType )
         return false; // not a match

      // consume
      scanner.advance();
      return true;
   }

   // consume an identifier, return boolean success
   private boolean consumeIdentifier(Scanner scanner)
   {
      if ( !isIdentifier(scanner.tokenType) )
         return false; // no I

      // consume I
      scanner.advance();
      return true;
   }

   // consume a type argument list, return boolean success
   // the elements should be be valid types: (I ::)? I TAL? (. I TAL?)*
   // if it safe to skip validity checking and just match any string of tokens containing
   // correctly balanced < & > – if there is an error Antlr will handle it
   private boolean consumeTAL(Scanner scanner)
   {
      int level = 1;

      while(level != 0)
      {
         scanner.advance();
         int tokenType = scanner.tokenType;

         switch(tokenType)
         {
            case TK_LT: level++; break;   // handle nested types
            case TK_GT: level--; break;

            case Token.EOF:
               return false;              // ran out of tokens, cannot be a TAL
            default:  ;
         }
      }

      // matched a TAL
      scanner.advance(); // consume closing GT
      return true;
   }

   // as above but for tuples
   private boolean consumeTuple(Scanner scanner)
   {
      int level = 1;

      while(level != 0)
      {
         scanner.advance();
         int tokenType = scanner.tokenType;

         switch(tokenType)
         {
            case TK_LPAREN: level++; break;   // handle nested tuples
            case TK_RPAREN: level--; break;

            case Token.EOF:
               return false;              // ran out of tokens, cannot be a tuple
            default:  ;
         }
      }

      // matched a tuple
      scanner.advance(); // consume closing RPAREN
      return true;
   }

   // utility for consumeBalancedText()
   // return matching closing “bracket” for an opening “bracket”
   private int closingTokenFor(int openingTokenType)
   {
      switch(openingTokenType)
      {
         case TK_LT:     return TK_GT;
         case TK_LPAREN: return TK_RPAREN;
         case TK_LBRACE: return TK_RBRACE;
         default:        return Token.EOF;   // should never happen
      }
   }

   // used by consumeItem() and checkTupleTypedDeclaration()
   //
   // consumes all text after an opening “bracket” (already consumed)
   // up to an including the matching closing “bracket”
   private boolean consumeBalancedText(Scanner scanner, int openingTokenType)
   {
      int closingTokenType = closingTokenFor(openingTokenType);

      if (closingTokenType == Token.EOF) return false; // should never happen

      while (true)
      {
         int tokenType = scanner.tokenType;

         switch(tokenType)
         {
            // handle balanced symbols
            case TK_LT:
            case TK_LPAREN:
            case TK_LBRACE:
               if (!consumeBalancedText(scanner.advance(), tokenType)) return false;

               // text balanced, loop
               continue;

            case Token.EOF:
               return false;              // ran out of tokens, cannot be valid item

            default:
               if (tokenType == closingTokenType)
               {
                  // found matching closing token, consume and return true
                  scanner.advance();
                  return true;
               }

               // anything else, consume and loop
               scanner.advance();
               continue;
         }
      }
   }

   // consume an item
   // used after item not recognised as a declaration to move on to the next item
   private boolean consumeItem(Scanner scanner)
   {
      while (true)
      {
         int tokenType = scanner.tokenType;

         switch(tokenType)
         {
            // handle balanced symbols
            case TK_LT:
            case TK_LPAREN:
            case TK_LBRACE:
               if (!consumeBalancedText(scanner.advance(), tokenType)) return false;

               // text balanced, loop
               continue;

            case Token.EOF:
               return false;              // ran out of tokens, cannot be valid item

            case TK_COMMA:
            case TK_RPAREN:
               // end of item, return true without advancing so caller can determine which
               return true;

            default:
               // anything else consume and loop
               scanner.advance();
               continue;
         }
      }
   }

   private boolean checkForDeclaration(Scanner scanner)
   {
      // check for "type identifier comma or rparen" – enough to recognise a simple declaration
      // do not advance cursor on failure

      int start = scanner.cursor; // save starting position, we can now advance and reset

      // type = (I ::)? I TAL? (. I TAL?)*
      // decl = type Simple_name (comma | rparen)
      // I: identifier
      // TAL: type argument list, balanced <…>

      if ( !consumeIdentifier(scanner) )
         return false; // no initial I, nothing consumed

      // check for optional I ::
      if (scanner.tokenType == TK_COLON_COLON)
      {
         // consume ::
         scanner.advance();

         // I :: – looking for I again
         if ( !consumeIdentifier(scanner) )
         {
            // no I
            scanner.reset(start);
            return false;
         }

         // I :: I
      }

      while(true)
      {
         // LT -> TAL, DOT -> I TAL?, I -> I (comma | rparen)

         if (scanner.tokenType == TK_LT)
         {
            if ( !consumeTAL(scanner) )
            {
               // LT but no TAL
               scanner.reset(start);
               return false;
            }
         }

         // (I ::)? I TAL?, check for DOT
         if ( !consumeKind(scanner, TK_DOT) )
         {
            // end of type, break out of loop
            break;
         }

         // (I ::)? I TAL? DOT – need an I

         if ( !consumeIdentifier(scanner) )
         {
            // no I
            scanner.reset(start);
            return false;
         }
      }

      // we have a complete type, looking for: I (comma | rparen)

      if ( !consumeIdentifier(scanner) )
      {
         // no I
         scanner.reset(start);
         return false;
      }

      if ( isCommaOrRParen(scanner.tokenType) )
      {
         //  found a declaration
         return true;
      }

      // no declaration found, reset scanner to start and return failure
      scanner.reset(start);
      return false;
   }

   // scan a non-abridged deconstructor for a declaration
   // return true as soon as one found
   // handles nested deconstructors through self recursion
   private boolean scanDeconstructorForDeclaration(Scanner scanner)
   {
      if (scanner.token.getType() != TK_LPAREN) return false;

      do
      {
         // skip opening LPAREN or element separating COMMA
         scanner.advance();

         // save starting position so can reset
         int startOffset = scanner.cursor;
         Token startToken = scanner.token;


         if ( checkForAbridgedDeconstructor(scanner) ) return true;

         if ( checkForSimpleDeclaration(scanner) ) return true;

         if ( checkForDeclaration(scanner) ) return true;

         // nested deconstructor?
         if ( scanDeconstructorForDeclaration(scanner) ) return true;

         // no declaration found for this element, reset and then scan element
         // simply balanced () & [] text – there could be an arbitrary expression to skip
         // stop at a comma - indicating another item to check, or an rparen, indicated end of deconstructor

         scanner.reset(startOffset);
         if (!consumeItem(scanner))
            return false; // failed to scan the item, assume its not a local_deconstructing_declaration
                          // and leave Antlr to sort it out

      } while (scanner.tokenType == TK_COMMA);

      return false;
   }

   private boolean checkDeconstructingDeclaration(ParserRuleContext currentctx)
   {
      Scanner scanner = new Scanner(_input);

      return scanDeconstructorForDeclaration(scanner);
   }

   // Checks for a tuple-typed declaration by checking for a tuple followed by an
   // identifier. We don’t need to check more than this as Antlr will do the rest.
   private boolean checkTupleTypedDeclaration(ParserRuleContext currentctx)
   {
      Scanner scanner = new Scanner(_input);

      scanner.advance(); // consume the LPAREN

      return consumeTuple(scanner) && consumeIdentifier(scanner);
   }

   // This predicate is used to enforce the semantic requirement that declaration
   // destructors contain at least one declaration expression. At the C#10+ language
   // level this to avoid ordinary destructors being misidentified as declaration
   // destructors.
   // Enforcing this semantic requirement in a full compiler need not be difficult,
   // but in this simple grammar checker due to the way Antlr works we need to
   // do token lookahead *before* the parse has taken place and this predicate
   // must be attached to declaration_statement rather than just the
   // local_deconstructing_declaration. This unfortunately means the predicate has
   // also to recognise tuple types which can occur as part of an ordinary declaration
   // (as opposed to a destructing one).
   boolean allowDeconstructingDeclarationPredicate(ParserRuleContext currentctx)
   {
      Token startToken = _input.LT(1);

      // If a declaration_statement does not start with a LPAREN it cannot be either
      // a tuple-typed declaration or a destructing declaration, pass
      // Note an abridged deconstructor is a declaration which does not start with an
      // LPAREN so this check will also pass those.

      if (startToken.getType() != TK_LPAREN) return true;

      // A tuple-typed declaration is of the form: T I (, I)* where T is a tuple type,
      // and I an identifier. This differs from destructors, declaring or not, which
      // are of the form: D = E where D is the destructor.
      // So if the declaration starts with D I it is a pass

      if ( checkTupleTypedDeclaration(currentctx) ) return true;

      // Finally we can check for a valid deconstructor

      return checkDeconstructingDeclaration(currentctx);

      // An abridged deconstructor is a valid declaration and does not start with a LPAREN,
      // so the first check will pass it.
      // A non-abridged deconstructor requires a declaration and does start with a LPAREN
      // so the second check will validate it.
//      return startToken.getType() != TK_LPAREN || checkDeconstructingDeclaration(currentctx);
   }

}
